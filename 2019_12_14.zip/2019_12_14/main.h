/**
 * \file main.h
 * \author BONTE Emeline, DEBART Arthur
 * \version final
 * \date 11 decembre 2019
 */

#ifndef MAIN_H
#define MAIN_H

#include "sdl-light.h"

void update_monstre(lab_t *lab);

void clean_data(lab_t *lab);

int is_game_over(lab_t *lab);

void apply_background(SDL_Surface *bg, SDL_Surface *screen);

void refresh_graphics(SDL_Surface *screen, lab_t *lab);

void handle_events(SDL_Event *event,lab_t *lab, SDL_Surface* screen);

int main( int argc, char* args[] );

#endif
