/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */



#include "colli.h"

/**
 * \brief La fonction gère la collision des pommes rouges entre_elles
 * \param p1 les données d'une pomme
 * \param p2 les données d'une pomme
 * \return 1 si collision, 0 sinon
 */
int colli_pomme_pomme(pomme_t *p1, pomme_t *p2){
	if( (p1-> px + SIZE_RIGHT_POMME >= p2-> px + SIZE_LEFT_POMME ) && (p1-> px + SIZE_LEFT_POMME <= p2-> px + SIZE_RIGHT_POMME ) ){
		if( (p1-> py + SIZE_POMME >= p2-> py + SIZE_LEFT_POMME ) && (p1-> py <= p2-> py + SIZE_POMME ) ){
			return 1;
		}
	}
	return 0;
}


/**
 * \brief La fonction gère la collision des pommes et des pierres
 * \param p1 les données d'une pomme
 * \param p2 les données d'une pomme
 * \param i la pomme rouge (1), verte (2), noire (3) et dorée (4)
 */
int colli_pomme_pierre(pomme_t *p1, pierre_t *p2, int i){
	if( (p1-> px + SIZE_RIGHT_POMME >= p2-> pa + SIZE_LEFT_POMME ) && (p1-> px + SIZE_LEFT_POMME <= p2-> pa + SIZE_RIGHT_POMME ) ){
		if( (p1-> py + SIZE_POMME >= p2-> pb + SIZE_LEFT_POMME ) && (p1-> py <= p2-> pb + SIZE_POMME ) ){
			if(i == 1){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
			if(i == 2 ){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
			if(i == 3 ){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
			if(i == 4){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
		}
	}
	return 0;
}

/**
 * \brief La fonction cree une nouvelle pomme
 * \param p les données d'une pomme
 */
void pomme_new(pomme_t *pomme){
	srand( (unsigned) time(NULL));
	pomme->px = rand() % 830 + 0;
	pomme->py = rand() % 430 + 0;
	pomme->exist = 1;
}

/**
 * \brief La fonction gère la collision des pommes
 * \param snake les données du monde serpent
 * \return x laquelle pomme, -1 si c'est aucune pomme
 */
int collision_pomme(snake_t *snake){
	int x = -1;
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PR[i], 1)){
				pomme_new(&snake->PR[i]);
				snake->laquel = 1;
				return x = i;
			}
		}
		if(snake-> PV[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PV[i], 2)){
				pomme_new(&snake->PV[i]);
				snake->laquel = 2;
				return x = i;
			}
		}
		if(snake-> PN[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PN[i], 3)){
				pomme_new(&snake->PN[i]);
				snake->laquel = 3;
				return x = i;
			}
		}
	}
	if(snake->T.L == 2){
		if(collision_pomme_serp(snake, &snake-> PO, 4)){
			snake->laquel = 4;
			return x = 12;
		}
	}
	return -1;
}

/**
 * \brief La fonction vérifie quelle pomme est en collision avec une autre
 * \param snake les données du monde serpent
 */
void pomme_pomme(snake_t *snake){
	for(int i = 0; i < snake-> nb_pomme; i++){
		for(int j = 0; j < snake-> nb_pomme; i++){
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PR[j+1])){
				pomme_new(&snake-> PR[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PV[i], &snake-> PV[j+1])){
				pomme_new(&snake-> PV[j]);
				return;		
			}
			if(colli_pomme_pomme(&snake-> PN[i], &snake-> PN[j+1])){
				pomme_new(&snake-> PN[j]);
				return;		
			}
			
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PV[j])){
				if(snake->laquel == 1){
					pomme_new(&snake-> PR[i]);
					return;
				}
				pomme_new(&snake-> PV[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PN[j])){
				if(snake->laquel == 1){
					pomme_new(&snake-> PR[i]);
					return;
				}
				pomme_new(&snake-> PN[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PO)){
				if(snake->laquel == 1){
					pomme_new(&snake-> PR[i]);
					return;
				}
				pomme_new(&snake-> PO);
				return;	
			}

			
			if(colli_pomme_pomme(&snake-> PV[i], &snake-> PN[j])){
				if(snake->laquel == 1){
					pomme_new(&snake-> PV[i]);
					return;
				}
				pomme_new(&snake-> PN[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PV[i], &snake-> PO)){
				if(snake->laquel == 1){
					pomme_new(&snake-> PV[i]);
					return;
				}
				pomme_new(&snake-> PO);
				return;	
			}

			if(colli_pomme_pomme(&snake-> PN[i], &snake-> PO)){
				if(snake->laquel == 1){
					pomme_new(&snake-> PN[i]);
					return;
				}
				pomme_new(&snake-> PO);
				return;	
			}
		}
	}
	return;
}


/**
 * \brief La fonction gère la collision des pommes les pierres
 * \param snake les données du monde serpent
 * \return x laquelle pomme, -1 si c'est aucune pomme
 */
int collision_pomme_pierre(snake_t *snake){
	int x = -1;
	for(int i = 0; i < snake->nb_pomme; i++){
		for(int j = 0; j < NB_PIERRE; j++){
			if(snake-> PR[i].exist == 1){
				if(colli_pomme_pierre(&snake-> PR[i], &snake-> P[j], 1)){
					pomme_new(&snake->PR[i]);
					snake->laquel = 1;
					return x = i;
				}
			}
			if(snake-> PV[i].exist == 1){
				if(colli_pomme_pierre(&snake-> PV[i], &snake-> P[j], 2)){
					pomme_new(&snake->PV[i]);
					snake->laquel = 2;
					return x = i;
				}
			}
			if(snake-> PN[i].exist == 1){
				if(colli_pomme_pierre(&snake-> PN[i], &snake-> P[j], 3)){
					pomme_new(&snake->PN[i]);
					snake->laquel = 3;
					return x = i;
				}
			}
			if(snake->T.L == 2){
				if(colli_pomme_pierre(&snake-> PO, &snake-> P[j], 4)){
					snake->laquel = 4;
					return x = 12;
				}
			}
		}
	}
	return -1;
}

