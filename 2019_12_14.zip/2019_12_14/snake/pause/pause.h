#ifndef MENU_H
#define MENU_H

//#include "../sdl-light.h"

void init_data_pause(pause_t *p);

//////////////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_pause(SDL_Surface *screen, pause_t *p);

void handle_events_pause(SDL_Event *event_pause, lab_t *lab, SDL_Surface *screen);

void boucle_menu(lab_t *lab, SDL_Surface *screen);

#endif
