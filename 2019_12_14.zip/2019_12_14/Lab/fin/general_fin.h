#include "../../sdl-light.h"
#include <stdbool.h>

/**
 * \brief Largeur des boutons
 */
#define LARGEUR_BOUTON_FIN 200

/**
 * \brief Hauteur des boutons
 */
#define HAUTEUR_BOUTON_FIN 80

/**
 * \brief Ecart entre le bouton et l'écran 
 */
#define ECART_BORDURE_FIN 45

/**
 * \brief Ecart de hauteur entre les boutons
 */
#define ECART_HAUTEUR_BOUTON_FIN 15

/**
 * \brief Ecart entre le bouton et l'écran en hauteur
 */
#define ECART_BORDURE_FIN2 220

/**
 * \brief Le nombre de bouton maximum dans le menu
 */ 
#define NB_BOUTON_MAX_FIN 8

///////////////////////////////////////////////////////////////////////////////struct souris/////////////////////////////////////////////////////////////////////////////////////

struct souris_fin_s{
	int x,y;
	int cx, cy;
};
typedef struct souris_fin_s souris_fin_t;

///////////////////////////////////////////////////////////////////////////////struct bouton/////////////////////////////////////////////////////////////////////////////////////

struct bouton_fin_s{
	SDL_Surface* Bouton;
	SDL_Surface* Bouton_des;
	SDL_Surface* Bouton_pas_des;
	int x, y;
	int larg;
	int haut;
	int lequel; //1 = bouton_1, 2 = bouton_2, ...
};
typedef struct bouton_fin_s bouton_fin_t;

///////////////////////////////////////////////////////////////////////////////struct menu///////////////////////////////////////////////////////////////////////////////////////

struct fin_s{
	SDL_Surface* Fin;
	bool ouvert;
	int nbBouton;
	bouton_fin_t taBouton[NB_BOUTON_MAX_FIN];
	souris_fin_t souris;
};
typedef struct fin_s fin_t;
