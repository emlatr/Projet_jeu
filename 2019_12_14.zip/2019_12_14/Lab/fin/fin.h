/**
 * \file fin.h
 * \author BONTE Emeline, DEBART Arthur
 * \version final
 * \date 11 decembre 2019
 */

#ifndef FIN_H
#define FIN_H

#include "../../sdl-light.h"

void init_data_souris_fin(souris_fin_t *s);

void init_data_bouton_fin_1(bouton_fin_t *b);

void init_data_bouton_fin_2(bouton_fin_t *b);

void init_data_bouton_fin_3(bouton_fin_t *b);

void init_data_bouton_fin_4(bouton_fin_t *b);

void init_data_bouton_fin_5(bouton_fin_t *b);

void init_data_bouton_fin_6(bouton_fin_t *b);

void init_data_bouton_fin_7(bouton_fin_t *b);

void init_data_bouton_fin_8(bouton_fin_t *b);

void init_data_bouton_fin_i(bouton_fin_t *b, int i);

void init_data_fin(fin_t *f);

/////////////////////////////////////////////////////////////////////////////////////////////////////

void init_graphic_fin_bouton(SDL_Surface *screen, bouton_fin_t *b);

void init_graphics_fin(SDL_Surface *screen, fin_t *f);

void refresh_graphics_fin_bouton(SDL_Surface *screen, bouton_fin_t *b);

void refresh_graphics_fin(SDL_Surface *screen, fin_t *f);

void lire_bouton_fin(bouton_fin_t *b, fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event);

void verif_pos_souris_fin_bouton(bouton_fin_t *b, souris_fin_t *s);

void verif_pos_souris_fin(fin_t * f);

void verif_clique_souris_fin_bouton(bouton_fin_t *b, souris_fin_t *s, fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event);

void verif_clique_souris_fin(fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event);

void verif_fin(fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event);

void update_clique_mouse_fin(souris_fin_t *s, int x, int y);

void update_pos_mouse_fin(souris_fin_t *s, int x, int y);

void handle_events_fin(SDL_Event *event_fin, lab_t *lab, SDL_Surface *screen);

void boucle_fin(lab_t *lab, SDL_Surface *screen);

#endif
