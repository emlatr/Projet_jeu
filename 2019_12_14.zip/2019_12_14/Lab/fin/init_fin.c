/**
 * \file init_fin.c
 * \brief Programme d'initialisation du menu de fin
 * \author BONTE Emeline, DEBART Arthur
 * \version fini
 * \date 11 decembre 2019
 */

//#include "../general.h"
#include "fin.h"

/**
 * \brief La fonction initialise la position de la souris
 * \param s les données de la souris
 */
void init_data_souris_fin(souris_fin_t *s){
	s-> x = -100;
	s-> y = -100;	
	s-> cx = -100;	
	s-> cy = -100;		 
}

/**
 * \brief La fonction initialise le 1er bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_1(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/snake1.2.bmp");
	b-> Bouton_pas_des = load_image("ressources/snake1.1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = ECART_BORDURE_FIN ; 

	b-> lequel = 1;
}

/**
 * \brief La fonction initialise le 2ième bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_2(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/snake2.2.bmp");
	b-> Bouton_pas_des = load_image("ressources/snake2.1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

 	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = ECART_BORDURE_FIN + b-> larg  + 83;

	b-> lequel = 2;
}

/**
 * \brief La fonction initialise le 3eme bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_3(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/snake3.2.bmp");
	b-> Bouton_pas_des = load_image("ressources/snake3.1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = ECART_BORDURE_FIN + b-> larg  + 83 + b-> larg  + 83;

	b-> lequel = 3;
}

/**
 * \brief La fonction initialise le 4ième bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_4(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/snake4.2.bmp");
	b-> Bouton_pas_des = load_image("ressources/snake4.1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

 	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN + HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = ECART_BORDURE_FIN ; 

	b-> lequel = 4;
}

/**
 * \brief La fonction initialise le 5eme bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_5(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/snake5.2.bmp");
	b-> Bouton_pas_des = load_image("ressources/snake5.1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN + HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = ECART_BORDURE_FIN + b-> larg  + 83 ;

	b-> lequel = 5;
}

/**
 * \brief La fonction initialise le 6ième bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_6(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/recommencer2.bmp");
	b-> Bouton_pas_des = load_image("ressources/recommencer1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

 	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN + HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = ECART_BORDURE_FIN + b-> larg  + 83 + b-> larg  + 83;

	b-> lequel = 6;
}

/**
 * \brief La fonction initialise le 7eme bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_7(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/regle2.bmp");
	b-> Bouton_pas_des = load_image("ressources/regle1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN + HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = 145 ; 

	b-> lequel = 7;
}

/**
 * \brief La fonction initialise le 8ième bouton du menu
 * \param b les données du bouton
 */
void init_data_bouton_fin_8(bouton_fin_t *b){
	b-> Bouton_des = load_image("ressources/quitter2.bmp");
	b-> Bouton_pas_des = load_image("ressources/quitter1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

 	b-> larg = LARGEUR_BOUTON_FIN;	
	b-> haut = HAUTEUR_BOUTON_FIN;

	b-> y = ECART_BORDURE_FIN2 + ECART_HAUTEUR_BOUTON_FIN + HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN + ECART_HAUTEUR_BOUTON_FIN;
	b-> x = SCREEN_WIDTH - 145 - LARGEUR_BOUTON_FIN;

	b-> lequel = 8;
}

/**
 * \brief La fonction initialise le ième bouton du menu
 * \param b les données du bouton
 * \param x l'écart entre la bordure et le bouton
 * \param i bouton 1(0), sinon bouton 2
 */
void init_data_bouton_fin_i(bouton_fin_t *b, int i){
	if(i == 0){
		init_data_bouton_fin_1(b);
		return;
	}
	if(i == 1){
		init_data_bouton_fin_2(b);
		return;
	}
	if(i == 2){
		init_data_bouton_fin_3(b);
		return;
	}
	if(i == 3){
		init_data_bouton_fin_4(b);
		return;
	}
	if(i == 4){
		init_data_bouton_fin_5(b);
		return;
	}
	if(i == 5){
		init_data_bouton_fin_6(b);
		return;
	}
	if(i == 6){
		init_data_bouton_fin_7(b);
		return;
	}
	init_data_bouton_fin_8(b);
	return;
}

/**
 * \brief La fonction initialise le menu
 * \param m les données du menu
 */
void init_data_fin(fin_t *f){	

	f-> Fin = load_image("ressources/fond_fin.bmp");

	f-> ouvert = true;

	f-> nbBouton = 8;

	for(int i = 0; i < f-> nbBouton; i++){
		init_data_bouton_fin_i(&f-> taBouton[i], i);
	}
	
	init_data_souris_fin(&f-> souris);	
}
