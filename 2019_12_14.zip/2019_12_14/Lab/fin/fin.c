/**
 * \file fin.c
 * \brief Programme de fin du jeu
 * \author BONTE Emeline, DEBART Arthur
 * \version final
 * \date 11 decembre 2019
 */

#include "fin.h"
//#include "init_fin.c"
#include "../../Regle/regle.h"
#include "../../snake/Niveaux/snake.h"
#include "../../main.h"

/**
 * \brief La fonction initialise les données du bouton
 * \param b les données du bouton
 * \param screen la surface correspondant à l'écran de jeu
 */
void init_graphic_fin_bouton(SDL_Surface *screen, bouton_fin_t *b){
	//set_transparence(screen, b-> Bouton_des, 255, 255, 255);
	//set_transparence(screen, b-> Bouton_pas_des, 255, 255, 255);
}

/**
 * \brief La fonction initialise les données du menu
 * \param m les données du menu
 * \param screen la surface correspondant à l'écran de jeu
 */
void init_graphics_fin(SDL_Surface *screen, fin_t *f){
	for(int i = 0; i < f-> nbBouton; i++){
		init_graphic_fin_bouton(screen, &f-> taBouton[i]);
	}	
}

////////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du bouton
 * \param screen la surface de l'écran de jeu
 * \param b les données du bouton
 */
void refresh_graphics_fin_bouton(SDL_Surface *screen, bouton_fin_t *b){
	apply_surface(b-> Bouton, screen, b-> x, b-> y);
}

/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du menu
 * \param screen la surface de l'écran de jeu
 * \param m les données du menu
 */
void refresh_graphics_fin(SDL_Surface *screen, fin_t *f){
	apply_surface(f-> Fin, screen, 0, 0);
	for(int i = 0; i < f-> nbBouton; i++){
		refresh_graphics_fin_bouton(screen, &f-> taBouton[i]);
	}
	refresh_surface(screen);
}

//////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction vérifie sur quel bouton on est et ferme le menu ou ouvre les regles
 * \selon le cas
 * \param screen la surface de l'écran de jeu
 * \param b les données du bouton
 * \param m les données du menu
 * \param lab les données du labyrinthe
 */
void lire_bouton_fin(bouton_fin_t *b, fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event){
	switch(b-> lequel){
		case 1 :
			boucle_snake(lab, screen);
		break;
		case 2 :
			boucle_snake2(lab, screen);
		break;
		case 3 :
			boucle_snake3(lab, screen);
		break;
		case 4 :
			boucle_snake4(lab, screen);
		break;
		case 5 :
			boucle_snake5(lab, screen);
		break;
		case 6 :
			//SDL_Event event;
			SDL_WM_SetCaption("Fenêtre de jeu de labyrinthe !", NULL);
			init_data(lab);
			init_mur(lab);
			init_graphics(screen,lab);
			//active la répétition des touches
			SDL_EnableKeyRepeat(100, 100); //en restant appuyé sur une touche le personnage bouge encore
			while(!is_game_over(lab)){
				SDL_WM_SetCaption("Fenêtre de jeu de labyrinthe !", NULL);
				/*déplace le personnage d'un mur à l'autre */
				collision_teleportation(lab);
				update_monstre(lab);
				handle_events(event,lab, screen);
				refresh_graphics(screen,lab);
				SDL_Delay(10);
					
			}
			clean_data(lab);
		break;
		case 7 :
			boucle_regle(lab, screen);
		break;
		case 8 :
			lab->gameover = 1;
			lab-> fin.ouvert = false;
		break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction vérifie la position de la souris sur le bouton
 * \param b les données du bouton
 * \param s les données de la souris 
 */
void verif_pos_souris_fin_bouton(bouton_fin_t *b, souris_fin_t *s){
	if((s-> x >= b-> x) && (s-> x <= b-> x + b-> larg)){
		if((s-> y >= b-> y) && (s-> y <= b-> y + b-> haut)){
			b-> Bouton = b-> Bouton_des;
			return;
		}
	}
	b-> Bouton = b-> Bouton_pas_des;
}

/**
 * \brief La fonction vérifie la position de la souris dans le menu
 * \param f les données du menu
 */
void verif_pos_souris_fin(fin_t * f){
	for(int i = 0; i < f-> nbBouton; i++){
		verif_pos_souris_fin_bouton(&f-> taBouton[i], &f-> souris);
	}
}

//////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction vérifie si on clique sur le bouton
 * \param screen la surface de l'écran de jeu
 * \param b les données du bouton
 * \param s les données de la souris 
 * \param f les données du menu
 * \param lab les données du labyrinthe
 */
void verif_clique_souris_fin_bouton(bouton_fin_t *b, souris_fin_t *s, fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event){
	if((s-> cx >= b-> x) && (s-> cx <= b-> x + b-> larg)){
		if((s-> cy >= b-> y) && (s-> cy <= b-> y + b-> haut)){
			lire_bouton_fin(b, f, lab, screen, event);
			s-> cx = -100;
			s-> cy = -100;
		}
	}
}

/**
 * \brief La fonction vérifie si on clique dans le menu
 * \param screen la surface de l'écran de jeu
 * \param f les données du menu
 * \param lab les données du labyrinthe
 */
void verif_clique_souris_fin(fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event){
	for(int i = 0; i < f-> nbBouton; i++){
		verif_clique_souris_fin_bouton(&f-> taBouton[i], &f-> souris, f, lab, screen, event);
	}
}

/**
 * \brief La fonction vérifie les cliques de la souris dans le menu et sa position
 * \param screen la surface de l'écran de jeu
 * \param f les données du menu
 * \param lab les données du labyrinthe
 */
void verif_fin(fin_t *f, lab_t *lab, SDL_Surface *screen, SDL_Event *event){
	verif_pos_souris_fin(f);
	verif_clique_souris_fin(f, lab, screen, event);
}

//////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction met à jour le clique de la souris 
 * \param s les données de la souris 
 * \param x position de la souris en x 
 * \param y position de la souris en y
 */
void update_clique_mouse_fin(souris_fin_t *s, int x, int y){
	s-> cx = x;
	s-> cy = y;
}

/**
 * \brief La fonction met à jour la position de la souris 
 * \param s les données de la souris 
 * \param x position de la souris en x 
 * \param y position de la souris en y
 */
void update_pos_mouse_fin(souris_fin_t *s, int x, int y){
	s-> x = x;
	s-> y = y;
}

/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event_fin paramètre qui contient les événements du menu
 * \param lab les données du monde
 * \param screen la surface de l'écran de jeu
 */
void handle_events_fin(SDL_Event *event_fin, lab_t *lab, SDL_Surface *screen){
	int mouseX, mouseY;

	while(SDL_PollEvent(event_fin)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event_fin-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
			lab-> fin.ouvert = false;
		}
		if(event_fin-> type == SDL_MOUSEBUTTONDOWN){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_clique_mouse_fin(&lab-> fin.souris, mouseX, mouseY);
		}
		if(event_fin-> type == SDL_MOUSEMOTION){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_mouse_fin(&lab-> fin.souris, mouseX, mouseY);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction implémente la boucle du menu
 * \param lab les données du monde
 * \param screen la surface de l'écran de jeu
 */
void boucle_fin(lab_t *lab, SDL_Surface *screen){
	SDL_Event event_fin;
	init_data_fin(&lab-> fin);
	init_graphics_fin(screen, &lab-> fin);
	while(lab-> fin.ouvert == true){
		handle_events_fin(&event_fin, lab, screen);
		verif_fin(&lab-> fin, lab, screen, &event_fin);
		refresh_graphics_fin(screen,&lab-> fin);
		SDL_Delay(100);
	}
}
