/**
 * \file colli_lab.h
 * \author BONTE Emeline, DEBART Arthur
 * \version final
 * \date 11 decembre 2019
 */

#ifndef COLLI_LAB_H
#define COLLI_LAB_H

void collision_fin(SDL_Surface *screen, lab_t *lab);

/**
 * \brief La fonction gère la collision entre les murs et le personnage
 * \param lab les données du monde
 * \return 1 si collision, 0 sinon
 */
int collision_mur_Jean(lab_t *lab);

/**
 * \brief La fonction gère la collision des coffres
 * \param c les données du coffres
 * \param screen l'écran de jeu
 * \param lab les données du monde
 */
void collision_coffre(lab_t* lab, coffre_t* c, SDL_Surface* screen);

/**
 * \brief La fonction verifie la collision avec tous les coffres et le personnage
 * \param lab les données du monde
 * \param screen l'écran de jeu
 */
void collision_coffre_Jean(lab_t *lab, SDL_Surface* screen);

/**
 * \brief La fonction verifie la collision avec tous les murs speciaux et le personnage
 * \param lab les données du monde
 */
void collision_teleportation(lab_t *lab);

/**
 * \brief La fonction verifie la collision avec les murs et le monstre
 * \param lab les données du monde
 * \param screen l'écran de jeu
 * \return 1 si collision, 0 sinon
 */
int colli_mur_monstre(lab_t *lab);

/**
 * \brief La fonction verifie la collision avec le monstre et le personnage
 * \param lab les données du monde
 * \param screen l'écran de jeu
 */
void colli_monstre_Jean(lab_t *lab);

#endif
