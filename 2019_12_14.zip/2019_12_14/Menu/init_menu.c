/**
 * \file init_menu.c
 * \brief Programme d'initialisation du menu
 * \author BONTE Emeline, DEBART Arthur
 * \version fini
 * \date 11 decembre 2019
 */

//#include "../general.h"
#include "menu.h"

/**
 * \brief La fonction initialise la position de la souris
 * \param s les données de la souris
 */
void init_data_souris_menu(souris_t *s){
	s-> x = -100;
	s-> y = -100;	
	s-> cx = -100;	
	s-> cy = -100;		 
}

/**
 * \brief La fonction initialise le 1er bouton du menu
 * \param b les données du bouton
 * \param x l'écart entre la bordure et le bouton
 */
void init_data_bouton_menu_1(bouton_menu_t *b, int x){
	b-> Bouton_des = load_image("ressources/jouer_2.bmp");
	b-> Bouton_pas_des = load_image("ressources/jouer_1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_MENU;	
	b-> haut = HAUTEUR_BOUTON_MENU;

	b-> y = SCREEN_HEIGHT/2 - b->haut/2;
	b-> x = x; 

	b-> lequel = 1;
}

/**
 * \brief La fonction initialise le 2ième bouton du menu
 * \param b les données du bouton
 * \param x l'écart entre la bordure et le bouton
 */
void init_data_bouton_menu_2(bouton_menu_t *b, int x){
	b-> Bouton_des = load_image("ressources/regle_2.bmp");
	b-> Bouton_pas_des = load_image("ressources/regle_1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

 	b-> larg = LARGEUR_BOUTON_MENU;	
	b-> haut = HAUTEUR_BOUTON_MENU;

	b-> y = SCREEN_HEIGHT/2 - b->haut/2;
	b-> x = x;

	b-> lequel = 2;
}

/**
 * \brief La fonction initialise le ième bouton du menu
 * \param b les données du bouton
 * \param x l'écart entre la bordure et le bouton
 * \param i bouton 1(0), sinon bouton 2
 */
void init_data_bouton_menu_i(bouton_menu_t *b, int x, int i){
	if(i == 0){
		init_data_bouton_menu_1(b, x);
		return;
	}
	init_data_bouton_menu_2(b, x);
	return;
}

/**
 * \brief La fonction initialise le menu
 * \param m les données du menu
 */
void init_data_menu(menu_t *m){
	int x = ECART_BORDURE_MENU;	

	m-> Menu = load_image("ressources/fond_menu.bmp");

	m-> ouvert = true;

	m-> nbBouton = 2;

	for(int i = 0; i < m-> nbBouton; i++){
		init_data_bouton_menu_i(&m-> taBouton[i], x, i);
		x = SCREEN_WIDTH - ECART_BORDURE_MENU - LARGEUR_BOUTON_MENU;
	}
	
	init_data_souris_menu(&m-> souris);	
}
