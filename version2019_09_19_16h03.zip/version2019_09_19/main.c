/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.1
 * \date 12 septembre 2019
 */

#include "sdl-light.h"

/**
 * \brief Largeur de l'écran de jeu
 */
#define SCREEN_WIDTH 550

/**
 * \brief Hauteur de l'écran de jeu
 */
#define SCREEN_HEIGHT 540

/**
 * \brief Taille d'un parchemin
 */
#define BUB_SIZE 40

/**
 * \brief Taille du bonhomme (sprite)
 */
#define SPRITE_SIZE 32

/**
 * \brief Pas de déplacement du sprite (bonhomme)
 */

#define MOVING_STEP 1




/**
 * \brief Représentation du monde du jeu
 */

struct world_s{
  SDL_Surface* background;
  SDL_Surface* Jean;
  SDL_Surface* Jean1;
  SDL_Surface* Jean2;
  SDL_Surface* Jean3;
  SDL_Surface* Jean4;
  int gameover;
  int x,y;
    
};

typedef struct world_s world_t;



/**
 * \brief La fonction initialise les données du monde du jeu
 * \param world les données du monde
 */


void init_data(world_t * world){
  //world->background = load_image( "ressources/pixil-frame-0(6).bmp" );  
  world->gameover = 0;
  world-> Jean4 = load_image( "ressources/Jean_dos2.bmp");
  world-> Jean3 = load_image( "ressources/Jean_cote_gauche2.bmp");

  world-> Jean2 = load_image( "ressources/Jean.bmp");
  world-> Jean1 = load_image( "ressources/Jean_face3.bmp");
  world-> Jean = load_image( "ressources/Jean_face3.bmp");//Le premier pers
  world-> x = 400.;
  world-> y = 0.;
}


/**
 * \brief La fonction nettoie les données du monde
 * \param world les données du monde
 */


void clean_data(world_t *world){
  SDL_FreeSurface(world->background);
  SDL_FreeSurface(world->Jean);
  SDL_FreeSurface(world->Jean1);
  SDL_FreeSurface(world->Jean2);
  SDL_FreeSurface(world->Jean3);
  SDL_FreeSurface(world->Jean4);
    
}




/**
 * \brief La fonction indique si le jeu est fini en fonction des données du monde
 * \param world les données du monde
 * \return 1 si le jeu est fini, 0 sinon
 */

int is_game_over(world_t *world){
  return world->gameover;
}


/**
 * \brief La fonction met à jour les données en tenant compte de la physique du monde
 * \param les données du monde
 */

void update_data(world_t *world){
}


/**
 * \brief La fonction initialise les transparences des différentes surfaces
 * \param screen la surface correspondant à l'écran de jeu
 * \param world les données du monde
 */

void  init_graphics(SDL_Surface *screen, world_t *world){
  /*set_transparence(screen, world->Jean, 255,255,255);
  set_transparence(screen, world->Jean1, 255,255,255);
  set_transparence(screen, world->Jean2, 255,255,255);
  set_transparence(screen, world->Jean3, 255,255,255);
  set_transparence(screen, world->Jean4, 255,255,255);*/
  
}


/**
 * \brief La fonction applique la surface de l'image de fond à quatre positions différentes sur l'écran de jeu, de sorte de complètement couvrir ce dernier
 * \param screen l'écran de jeu
 * \param bg la surface de l'image de fond
 */
void apply_background(SDL_Surface *bg, SDL_Surface *screen){
   apply_surface(bg,screen,0,0);

	
}





/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du monde
 * \param screen la surface de l'écran de jeu
 * \param world les données du monde
 */

void refresh_graphics(SDL_Surface *screen, world_t *world){
  apply_background(world->background,screen);
  apply_surface(world->Jean, screen, world->x , world->y);
    
    
    
  refresh_surface(screen);
}

void affichage (world_t *world){
  printf("x = %d, y = %d", world->x,world->y);
}

/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event paramètre qui contient les événements
 * \param world les données du monde
 */


void handle_events(SDL_Event *event,world_t *world){
  Uint8 *keystates;
	
  	affichage(world);  

  while( SDL_PollEvent( event ) ) {
    //Si l'utilisateur a cliqué sur le X de la fenêtre
    if( event->type == SDL_QUIT ) {
      //On quitte le programme
      world->gameover = 1;
    }
        
    /* gestion des evenements clavier */
    keystates = SDL_GetKeyState( NULL );

    /* Si l'utilisateur appuie sur les flèches, le personnage se déplace */
    if( keystates[ SDLK_UP])
      {
	//world->Jean = world->Jean4;
	world->y-=10;

      }
    if( keystates[ SDLK_DOWN])
      {
	world->Jean = world->Jean1;
	world->y+=10;
	
      }
    if( keystates[ SDLK_RIGHT])
      {
	//world->Jean = world->Jean2;
	world->x+=10;
      }
    if( keystates[ SDLK_LEFT])
      {
	//world->Jean = world->Jean3;
	world->x-=10;
      }
        
        
  }
    
}


typedef struct Laby
{
    int** tab;
    int taille;
} Laby;

void Preparer(Laby* l)
{
    int i,j,cpt;
    l->tab = malloc(l->taille*sizeof(int*));
    for(i=0;i<l->taille;i++)
        l->tab[i] = malloc(l->taille*sizeof(int));
    for(cpt=1,i=0;i<l->taille;i++)
        for(j=0;j<l->taille;j++)
            if (i%2==1 && j%2==1)
                l->tab[i][j] = cpt++;
            else
                l->tab[i][j] = 0;
}

void Afficher(Laby* l)
{
    int i,j;
    for(i=0;i<l->taille;i++)
    {
        for(j=0;j<l->taille;j++)
            printf("%c",(l->tab[i][j]==0)?'*':'.');
        printf("\n");
    }
}

void Liberer(Laby* l)
{
    int i;
    for(i=0;i<l->taille;i++)
        free(l->tab[i]);
    free(l->tab);
}

void Remplacer(Laby* l,int anc,int nouv)
{
    int i,j;
    for(i=0;i<l->taille;i++)
        for(j=0;j<l->taille;j++)
            if (l->tab[i][j]==anc)
                l->tab[i][j] = nouv;
}

void Generer(Laby* l)
{
    int vec[4][2] = {{1,0},{-1,0},{0,1},{0,-1}};
    int nbzones = ((l->taille-1)/2)*((l->taille-1)/2);
    while(nbzones>1)
    {
        int i,x,y,zone1;
        zone1 = 0;
        x = rand()%(l->taille-2)+1;
        y = rand()%(l->taille-2)+1;
        if (l->tab[x][y]!=0)
            continue; // pas un mur
        for(i=0;i<4;i++)
        {
            int valzone = l->tab[x+vec[i][0]][y+vec[i][1]];
            if (valzone>0)
            {
                if (zone1==0 || zone1 == valzone)
                    zone1 = valzone;
                else
                { // fusion
                    l->tab[x][y] = zone1;
                    Remplacer(l,valzone,zone1);
                    nbzones--;
                    break;
                }
            }        
        }
    }
}





/**
 *  \brief programme principal qui implémente la boucle du jeu
 */


int main( int argc, char* args[] )
{
  SDL_Event event;
  world_t world;
  SDL_Surface *screen;

  screen = init_sdl(SCREEN_WIDTH, SCREEN_HEIGHT);
  SDL_WM_SetCaption("Fenêtre de jeu de labyrinthe !", NULL);
    
  init_data(&world);
  init_graphics(screen,&world);
  
  SDL_EnableKeyRepeat(100, 100); //active la répétition des touches
 
  
  while(!is_game_over(&world)){
    
    handle_events(&event,&world);
    update_data(&world);
    refresh_graphics(screen,&world);
    SDL_Delay(10);


    Laby l;
    srand((unsigned int)time(NULL));
    printf("taille ? Impaire et au moins 3: ");
    scanf("%d",&(l.taille));
    if (l.taille<3 || l.taille%2==0)
        return -1;  // relis la question.
    Preparer(&l);
    Generer(&l);
    Afficher(&l);
    Liberer(&l);
    return 0;
  }

  clean_data(&world);
  quit_sdl();
    
    
  return 0;
}
