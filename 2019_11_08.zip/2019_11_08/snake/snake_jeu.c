/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

//#include "../sdl-light.h"
//#include "../general.h"
#include <time.h>

int pomme_alea(){
	srand( (unsigned) time(NULL));
	int choix = rand()%4-1;
	return choix;
}

void pomme_new(int i, pomme_t *pomme){
	srand( (unsigned) time(NULL));
	i = 1;
	if(i == 1){
		pomme->px = rand() % 830 + 0;
		pomme->py = rand() % 430 + 0;
		pomme->exist = 1;
		printf("%i, %i\n",pomme->px, pomme->py);
	}
}

int collision_pomme(snake_t *snake){
	int x = -1;
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PR[i], 1)){
				pomme_new(pomme_alea(), &snake->PR[i]);
				return x = i;
			}
		}
		/*if(snake-> PV[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PV[i], 2)){
				return y = i;
			}
		}*/
	}
	return -1;
}
