/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */
#ifndef INIT_SNAKE_H
#define INIT_SNAKE_H


void init_data_snake2(snake_t *snake);
 
void init_data_pomme2(snake_t *snake);

void init_graphics_snake2(SDL_Surface *screen, snake_t *snake);

#endif
