/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include <time.h>
#include "init.h"


/**
 * \brief La fonction initialise les données du monde du jeu
 * \param world les données du monde
 */


void init_data_snake(snake_t *snake){ 
	snake-> fond = load_image( "ressources/fond.bmp" );
	snake-> background = load_image( "ressources/herbe.bmp" );
	snake-> corps.Corps = load_image("ressources/corps.bmp");
	snake-> gameover = 0;
	snake-> Serpent = load_image( "ressources/tete2.bmp");//Le premier serpentserpent_tete.
	snake-> x = 0.;
	snake-> y = 0.;
	snake-> C[0].cx = 0;
	snake-> C[0].cy = 32;
	snake-> C[0].Corps = snake->corps.Corps;
	for(int i = 1; i < NB_CORPS_SNAKE; i++){
		snake-> C[i].cx = snake-> C[i-1].cx;
		snake-> C[i].cy = snake-> C[i-1].cy;
		snake-> C[i].Corps = snake-> corps.Corps;
	}
	snake-> vx = 9;
	snake-> vy = 9;
	snake-> direct = 3;
	snake-> nb_corps = 1;
	snake-> score = 0;
	snake-> ouvert = true;
	snake-> nb_pomme = 6;
	
}

void init_data_pomme(snake_t *snake){ 
	srand((unsigned)time(NULL));
	for(int i = 0; i< snake->nb_pomme; i++){
		snake-> PR[i].Pomme = load_image("ressources/pomme.bmp" );
		snake-> PR[i].px = rand() % 830 + 0;
		snake-> PR[i].py = rand() % 430 + 0;
		snake-> PR[i].exist = 1;
		snake-> PV[i].Pomme = load_image("ressources/pomme_verte.bmp" );
		snake-> PV[i].px = rand() % 830 + 0;
		snake-> PV[i].py = rand() % 430 + 0;
		snake-> PV[i].exist = 1;
		snake-> PN[i].Pomme = load_image("ressources/pomme_noire.bmp" );
		snake-> PN[i].px = rand() % 830 + 0;
		snake-> PN[i].py = rand() % 430 + 0;
		snake-> PN[i].exist = 1;
	}
}


/**
 * \brief La fonction initialise les transparences des différentes surfaces
 * \param screen la surface correspondant à l'écran de jeu
 * \param world les données du monde
 */
void init_graphics_snake(SDL_Surface *screen, snake_t *snake){
	//int* memoire = NULL;
	//memoire = malloc(sizeof(int));
	for(int i = 0; i < snake->nb_pomme; i++){
		set_transparence(screen, snake-> PR[i].Pomme, 255,255,255);
		set_transparence(screen, snake-> PV[i].Pomme, 255,255,255);
	}
	set_transparence(screen, snake-> Serpent, 255,255,255);
	set_transparence(screen, snake-> corps.Corps, 255,255,255);
}

