/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

//#include "../sdl-light.h"
//#include "../general.h"
#include <time.h>

/*int pomme_alea(){
	srand( (unsigned) time(NULL));
	int choix = rand()%3-1;
	return choix;
}*/

void pomme_new(pomme_t *pomme){
	srand( (unsigned) time(NULL));
	pomme->px = rand() % 830 + 0;
	pomme->py = rand() % 430 + 0;
	pomme->exist = 1;
}

int collision_pomme(snake_t *snake){
	int x = -1;
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PR[i], 1)){
				pomme_new(&snake->PR[i]);
				return x = i;
			}
		}
		if(snake-> PV[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PV[i], 2)){
				pomme_new(&snake->PV[i]);
				return x = i;
			}
		}
		if(snake-> PN[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PN[i], 3)){
				pomme_new(&snake->PN[i]);
				return x = i;
			}
		}
	}
	if(snake->T.L == 2){
		if(collision_pomme_serp(snake, &snake-> PO, 4)){
			return x = 12;
		}
	}
	return -1;
}


