/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */
#ifndef COLLI_SNAKE_H
#define COLLI_SNAKE_H

int collision_snake (snake_t *snake);

void replacement_serpent(snake_t *snake);

int collision_pomme_serp(snake_t *snake, pomme_t *p, int i);

int collision_tete_corps(snake_t *snake, corps_t *corps);

int collision_corps(snake_t *snake);

int collision_pierre_serp(snake_t *snake, pierre_t *p);

int collision_eau_serp(snake_t *snake, eau_t *e);


#endif
