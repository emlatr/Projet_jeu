/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.1
 * \date 12 septembre 2019
 */


#ifndef SNAKEJEU_H
#define SNAKEJEU_H

//int pomme_alea();

void pomme_new(snake_t *snake, int i);

int collision_pomme_rouge(snake_t *snake);
	
int collision_pomme_alea(snake_t *snake);

#endif
