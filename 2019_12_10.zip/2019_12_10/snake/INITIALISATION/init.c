/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include <time.h>
#include "init.h"


/**
 * \brief La fonction initialise les données du monde du jeu
 * \param world les données du monde
 */


void init_data_snake(snake_t *snake){ 
	snake-> fond = load_image( "ressources/fond.bmp" );
	snake-> background = load_image( "ressources/herbe.bmp" );
	snake-> corps.Corps = load_image("ressources/corps.bmp");
	snake-> gameover = 0;
	snake-> Serpent = load_image( "ressources/tete2.bmp");//Le premier serpentserpent_tete.
	snake-> x = 0.;
	snake-> y = 0.;
	snake-> C[0].cx = 0;
	snake-> C[0].cy = 32;
	snake-> C[0].Corps = snake->corps.Corps;
	for(int i = 1; i < NB_CORPS_SNAKE; i++){
		snake-> C[i].cx = -100 ;//snake-> C[i-1].cx;
		snake-> C[i].cy = -100; //snake-> C[i-1].cy;
		snake-> C[i].Corps = snake-> corps.Corps;
	}
	snake-> vx = 9;
	snake-> vy = 9;
	snake-> direct = 3;
	snake-> nb_corps = 1;
	snake-> score = 0;
	snake-> ouvert = true;
	snake-> laquel = 0;
	
}

void init_data_snake3_4(snake_t *snake){ 
	snake-> fond = load_image( "ressources/fond.bmp" );
	snake-> background = load_image( "ressources/herbe.bmp" );
	snake-> corps.Corps = load_image("ressources/corps2.bmp");
	snake-> gameover = 0;
	snake-> Serpent = load_image( "ressources/tete2_1.bmp");//Le premier serpentserpent_tete.
	snake-> x = 0.;
	snake-> y = 0.;
	snake-> C[0].cx = 0;
	snake-> C[0].cy = 32;
	snake-> C[0].Corps = snake->corps.Corps;
	for(int i = 1; i < NB_CORPS_SNAKE; i++){
		snake-> C[i].cx = -100; //snake-> C[i-1].cx;
		snake-> C[i].cy = -100; //snake-> C[i-1].cy;
		snake-> C[i].Corps = snake-> corps.Corps;
	}
	snake-> vx = 13;
	snake-> vy = 13;
	snake-> direct = 3;
	snake-> nb_corps = 1;
	snake-> score = 0;
	snake-> ouvert = true;
	snake-> laquel = 0;
	
}



int init_nb_pomme(snake_t *snake, int i){
	if(i == 1)
		return  6;
	if(i == 2)
		return 2;
	if(i == 3)
		return  2;
	else 
		return 4;
	return 0;
}


void init_data_pomme1(snake_t *snake){ 
	srand((unsigned)time(NULL));
	for(int i = 0; i< snake->nb_pomme; i++){
		snake-> PR[i].Pomme = load_image("ressources/pomme.bmp" );
		snake-> PR[i].px = rand() % 830 + 0;
		snake-> PR[i].py = rand() % 430 + 0;
		snake-> PR[i].exist = 1;
	}
}

void init_data_pomme_or(SDL_Surface *screen, snake_t *snake){ 
	srand((unsigned)time(NULL));
	snake-> PO.Pomme = load_image("ressources/pomme_dore.bmp" );
	snake-> PO.px = -100 ;
	snake-> PO.py = -100 ;
	set_transparence(screen, snake-> PO.Pomme, 255,255,255);
}

void init_data_pomme(snake_t *snake){ 
	srand((unsigned)time(NULL));
	for(int i = 0; i< snake->nb_pomme; i++){
		snake-> PR[i].Pomme = load_image("ressources/pomme.bmp" );
		snake-> PR[i].px = rand() % 830 + 0;
		snake-> PR[i].py = rand() % 430 + 0;
		snake-> PR[i].exist = 1;
		snake-> PV[i].Pomme = load_image("ressources/pomme_verte.bmp" );
		snake-> PV[i].px = rand() % 830 + 0;
		snake-> PV[i].py = rand() % 430 + 0;
		snake-> PV[i].exist = 1;
		snake-> PN[i].Pomme = load_image("ressources/pomme_noire.bmp" );
		snake-> PN[i].px = rand() % 830 + 0;
		snake-> PN[i].py = rand() % 430 + 0;
		snake-> PN[i].exist = 1;
	}
}

void init_graphics_snake2(SDL_Surface *screen, snake_t *snake){
	for(int i = 0; i < snake->nb_pomme; i++){
		set_transparence(screen, snake-> PR[i].Pomme, 255,255,255);
		set_transparence(screen, snake-> PV[i].Pomme, 255,255,255);
		set_transparence(screen, snake-> PN[i].Pomme, 255,255,255);
	}
	set_transparence(screen, snake-> Serpent, 255,255,255);
	set_transparence(screen, snake-> corps.Corps, 255,255,255);
}


/**
 * \brief La fonction initialise les transparences des différentes surfaces
 * \param screen la surface correspondant à l'écran de jeu
 * \param world les données du monde
 */
void init_graphics_snake(SDL_Surface *screen, snake_t *snake){
	for(int i = 0; i < snake->nb_pomme; i++){
		set_transparence(screen, snake-> PR[i].Pomme, 255,255,255);
	}
	set_transparence(screen, snake-> Serpent, 255,255,255);
	set_transparence(screen, snake-> corps.Corps, 255,255,255);
}

void init_pierre(SDL_Surface *screen, snake_t *snake){
	srand((unsigned)time(NULL));
	for(int i = 0; i < NB_PIERRE ; i++){
		snake-> P[i].Pierre = load_image("ressources/pierre.bmp" );
		snake-> P[i].pa = rand() % 818 + 0;
		snake-> P[i].pb = rand() % 418 + 0;
		set_transparence(screen, snake-> P[i].Pierre, 255,255,255);
	}
}

void init_eau(SDL_Surface *screen, snake_t *snake){
	srand((unsigned)time(NULL));
	snake-> E.Eau = load_image("ressources/eau.bmp" );
	snake-> E.ex = rand() % 722 + 0;
	snake-> E.ey = rand() % 376 + 0;
	set_transparence(screen, snake-> E.Eau, 255,255,255);
}

void init_timer(snake_t *snake){
	snake->T.TA = SDL_GetTicks();
	snake->T.TM = SDL_GetTicks();
	snake->T.EA = 30000; //pour 30 secondes
	snake->T.ER = 10000; //pour 10 secondes
	snake->T.L = 1;
}

