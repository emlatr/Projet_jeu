#include "../../general.h"

void init_data_resultat(resultat_t *r, SDL_Surface *screen){

	r-> Gagner = load_image("ressources/bravo.bmp");
	
	//set_transparence(screen, r-> Gagner, 255,255,255);
	r-> Perdu = load_image("ressources/perdu.bmp");

	r-> ouvert_gagne = true;
	r-> ouvert_perdu = true;
	
}
