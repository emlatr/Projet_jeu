#ifndef INIT_RESULTAT_H
#define INIT_RESULTAT_H

#include "../../sdl-light.h"

void init_data_resultat(resultat_t *r, SDL_Surface *screen);

#endif
