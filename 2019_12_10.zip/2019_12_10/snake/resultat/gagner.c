#include "../../general.h"


////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_gagner(SDL_Surface *screen, resultat_t *r){
	apply_surface(r-> Gagner, screen, 0, 0);
	refresh_surface(screen);
}

///////////////////////////////////////////////////////////////////////////////////////

void handle_events_gagner(SDL_Event *event_gagne, lab_t *lab, SDL_Surface *screen){
	Uint8 *keystates;
	while(SDL_PollEvent(event_gagne)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event_gagne-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
			lab->snake.gagne.ouvert_gagne = false;
		}
		/* gestion des evenements clavier */
		keystates = SDL_GetKeyState(NULL);
		/* Si l'utilisateur appuie sur les flèches, le personnage se déplace */
		if(keystates[SDLK_ESCAPE])
		{
			lab->snake.gagne.ouvert_gagne = false;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void boucle_gagner(lab_t *lab, SDL_Surface *screen){
	SDL_Event event_gagne;
	init_data_resultat(&lab->snake.gagne, screen);
	while(lab->snake.gagne.ouvert_gagne == true){
		handle_events_gagner(&event_gagne, lab, screen);
		refresh_graphics_gagner(screen,&lab->snake.gagne);
		SDL_Delay(100);
	}
}
