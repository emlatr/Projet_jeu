/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */
#ifndef INIT_LAB_H
#define INIT_LAB_H

void init_data(lab_t *lab);

void init_coffre(lab_t *lab);

void init_monstre(lab_t *lab);

void init_mur(lab_t * lab);

void init_graphics(SDL_Surface *screen, lab_t *lab);

#endif
