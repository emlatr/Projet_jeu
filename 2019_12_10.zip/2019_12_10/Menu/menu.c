#include "../general.h"

void init_graphic_menu_bouton(SDL_Surface *screen, bouton_menu_t *b){
	set_transparence(screen, b-> Bouton_des, 255, 255, 255);
	set_transparence(screen, b-> Bouton_pas_des, 255, 255, 255);
}


void init_graphics_menu(SDL_Surface *screen, menu_t *m){
	for(int i = 0; i < m-> nbBouton; i++){
		init_graphic_menu_bouton(screen, &m-> taBouton[i]);
	}	
}

////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_menu_bouton(SDL_Surface *screen, bouton_menu_t *b){
	apply_surface(b-> Bouton, screen, b-> x, b-> y);
}

void refresh_graphics_menu(SDL_Surface *screen, menu_t *m){
	apply_surface(m-> Menu, screen, 0, 0);
	for(int i = 0; i < m-> nbBouton; i++){
		refresh_graphics_menu_bouton(screen, &m-> taBouton[i]);
	}
	refresh_surface(screen);
}



//////////////////////////////////////////////////////////////////////////////////////

void lire_bouton_menu(bouton_menu_t *b, menu_t *m, lab_t *lab, SDL_Surface *screen){
	switch(b-> lequel){
		case 1 :
			m-> ouvert = false;
		break;
		case 2 :
			boucle_regle(lab, screen);
		break;
	}
}

//////////////////////////////////////////////////////////////////////////////////////

void verif_pos_souris_menu_bouton(bouton_menu_t *b, souris_t *s){
	if((s-> x >= b-> x) && (s-> x <= b-> x + b-> larg)){
		if((s-> y >= b-> y) && (s-> y <= b-> y + b-> haut)){
			b-> Bouton = b-> Bouton_des;
			return;
		}
	}
	b-> Bouton = b-> Bouton_pas_des;
}

void verif_pos_souris_menu(menu_t * m){
	for(int i = 0; i < m-> nbBouton; i++){
		verif_pos_souris_menu_bouton(&m-> taBouton[i], &m-> souris);
	}
}

//////////////////////

void verif_clique_souris_menu_bouton(bouton_menu_t *b, souris_t *s, menu_t *m, lab_t *lab, SDL_Surface *screen){
	if((s-> cx >= b-> x) && (s-> cx <= b-> x + b-> larg)){
		if((s-> cy >= b-> y) && (s-> cy <= b-> y + b-> haut)){
			lire_bouton_menu(b, m, lab, screen);
			s-> cx = -100;
			s-> cy = -100;
		}
	}
}

void verif_clique_souris_menu(menu_t *m, lab_t *lab, SDL_Surface *screen){
	for(int i = 0; i < m-> nbBouton; i++){
		verif_clique_souris_menu_bouton(&m-> taBouton[i], &m-> souris, m, lab, screen);
	}
}

void verif_menu(menu_t *m, lab_t *lab, SDL_Surface *screen){
	verif_pos_souris_menu(m);
	verif_clique_souris_menu(m, lab, screen);
}

//////////////////////////////////////////////////////////////////////////////////////

void update_clique_mouse_menu(souris_t *s, int x, int y){
	s-> cx = x;
	s-> cy = y;
}

void update_pos_mouse_menu(souris_t *s, int x, int y){
	s-> x = x;
	s-> y = y;
}

void handle_events_menu(SDL_Event *event_menu, lab_t *lab, SDL_Surface *screen){
	int mouseX, mouseY;

	while(SDL_PollEvent(event_menu)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event_menu-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
		}
		if(event_menu-> type == SDL_MOUSEBUTTONDOWN){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_clique_mouse_menu(&lab-> menu.souris, mouseX, mouseY);
		}
		if(event_menu-> type == SDL_MOUSEMOTION){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_mouse_menu(&lab-> menu.souris, mouseX, mouseY);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void boucle_menu(lab_t *lab, SDL_Surface *screen){
	SDL_Event event_menu;
	init_data_menu(&lab-> menu);
	init_graphics_menu(screen, &lab-> menu);
	while(lab-> menu.ouvert == true){
		handle_events_menu(&event_menu, lab, screen);
		verif_menu(&lab-> menu, lab, screen);
		refresh_graphics_menu(screen,&lab-> menu);
		SDL_Delay(100);
	}
}
