#ifndef MENU_H
#define MENU_H

#include "../sdl-light.h"

void init_graphic_menu_bouton(SDL_Surface *screen, bouton_menu_t *b);

void init_graphics_menu(SDL_Surface *screen, menu_t *m);

void refresh_graphics_menu_bouton(SDL_Surface *screen, bouton_menu_t *b);

void refresh_graphics_menu(SDL_Surface *screen, menu_t *m);

void lire_bouton_menu(bouton_menu_t *b, menu_t *m, lab_t *lab, SDL_Surface *screen);

void verif_pos_souris_menu_bouton(bouton_menu_t *b, souris_t *s);

void verif_pos_souris_menu(menu_t * m);

void verif_clique_souris_menu_bouton(bouton_menu_t *b, souris_t *s, menu_t *m, lab_t *lab, SDL_Surface *screen);

void verif_clique_souris_menu(menu_t *m, lab_t *lab, SDL_Surface *screen);

void verif_menu(menu_t *m, lab_t *lab, SDL_Surface *screen);

void update_clique_mouse_menu(souris_t *s, int x, int y);

void update_pos_mouse_menu(souris_t *s, int x, int y);

void handle_events_menu(SDL_Event *event_menu, lab_t *lab, SDL_Surface *screen);

void boucle_menu(lab_t *lab, SDL_Surface *screen);

#endif
