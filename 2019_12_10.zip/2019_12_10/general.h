/**
 * \file general.h
 * \brief Programme general pour toutes les valeurs stables et les structures
 * \author Emeline BONTE, Arthur DEBART
 * \version 0.1
 * \date 21 mars 2019-27 mai 2019
 */

#include "sdl-light.h"
#include "Menu/general_menu.h"
#include "Regle/general_regle.h"
#include "snake/general_snake.h"
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>

/////////////////////////////////////////////////////////////////////////////////labyrinthe///////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief Largeur de l'écran de jeu
 */
#define SCREEN_WIDTH 850

/**
 * \brief Hauteur de l'écran de jeu
 */
#define SCREEN_HEIGHT 550

/**
 * \brief Nombre de mur dans le labyrinthe
 */
#define NB_MUR 52

/**
 * \brief Nombre maximum de coffre
 */
#define NB_COFFRE 5

/**
 * \brief Taille du coffre a droite
 */
#define SIZE_RIGHT_COFFRE 16

/**
 * \brief Taille du  coffre à gauche
 */
#define SIZE_LEFT_COFFRE 0

/**
 * \brief Taille du coffre en bas
 */
#define SIZE_BOTTOM_COFFRE 14

/**
 * \brief Taille du  coffre en haut
 */
#define SIZE_TOP_COFFRE 0


/////////////////////////////////////////////////////////////////////////////////struct mur///////////////////////////////////////////////////////////////////////////////////////

struct monstre_s{
	SDL_Surface* Monstre;
	SDL_Surface* Monstreface;
	SDL_Surface* Monstredos;
	double mx,my;
	double vmx, vmy;
	int direct; //0:descend, 1: monte, 2: droite, 3: gauche

};
typedef struct monstre_s monstre_t;

/////////////////////////////////////////////////////////////////////////////////struct mur///////////////////////////////////////////////////////////////////////////////////////

struct mur_s{
	int x,y;
	int larg, haut;

};
typedef struct mur_s mur_t;



/////////////////////////////////////////////////////////////////////////////////struct coffre////////////////////////////////////////////////////////////////////////////////////

struct coffre_s{
	SDL_Surface* Coffre;
	double cx,cy;
	int exist;
};
typedef struct coffre_s coffre_t;


/////////////////////////////////////////////////////////////////////////////////struct labyrinthe////////////////////////////////////////////////////////////////////////////////

struct lab_s{
	SDL_Surface* background;
	SDL_Surface* Lampe;
	SDL_Surface* Lampe_droite;
	SDL_Surface* Lampe_gauche;
	SDL_Surface* Lampe_bas;
	SDL_Surface* Lampe_haut;
	SDL_Surface* Jean;
	SDL_Surface* Jean1;
	SDL_Surface* Jean2;
	SDL_Surface* Jean3;
	SDL_Surface* Jean4;
	SDL_Surface* intero;
	int gameover;
	int x,y;//position du Jean
	mur_t M[NB_MUR];
	int deplace;
	int compt;
	coffre_t Co[NB_COFFRE];
	snake_t snake; 
	menu_t menu; 
	regle_t regle;
	monstre_t monstre;
};
typedef struct lab_s lab_t;


