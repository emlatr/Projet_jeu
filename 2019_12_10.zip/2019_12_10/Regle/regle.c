#include "../general.h"

void init_graphic_regle_bouton(SDL_Surface *screen, bouton_regle_t *b){
	set_transparence(screen, b-> Bouton_des, 255, 255, 255);
	set_transparence(screen, b-> Bouton_pas_des, 255, 255, 255);
}


void init_graphics_regle(SDL_Surface *screen, regle_t *r){
	init_graphic_regle_bouton(screen, &r-> bouton);
		
}

////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_regle_bouton(SDL_Surface *screen, bouton_regle_t *b){
	apply_surface(b-> Bouton, screen, b-> x, b-> y);
}

void refresh_graphics_regle(SDL_Surface *screen, regle_t *r){
	apply_surface(r-> Regle, screen, 0, 0);
	refresh_graphics_regle_bouton(screen, &r-> bouton);	
	refresh_surface(screen);
}

//////////////////////////////////////////////////////////////////////////////////////

void verif_pos_souris_regle_bouton(bouton_regle_t *b, souris_regle_t *s){
	if((s-> x >= b-> x) && (s-> x <= b-> x + b-> larg)){
		if((s-> y >= b-> y) && (s-> y <= b-> y + b-> haut)){
			b-> Bouton = b-> Bouton_des;
			return;
		}
	}
	b-> Bouton = b-> Bouton_pas_des;
}

//////////////////////

void verif_clique_souris_regle_bouton(bouton_regle_t *b, souris_regle_t *s, regle_t *r){
	if((s-> cx >= b-> x) && (s-> cx <= b-> x + b-> larg)){
		if((s-> cy >= b-> y) && (s-> cy <= b-> y + b-> haut)){
			r-> ouvert = false;
		}
	}
}

void verif_regle(regle_t *r){
	verif_pos_souris_regle_bouton(&r-> bouton, &r-> souris);
	verif_clique_souris_regle_bouton(&r-> bouton, &r-> souris, r);
}

//////////////////////////////////////////////////////////////////////////////////////

void update_clique_mouse_regle(souris_regle_t *s, int x, int y){
	s-> cx = x;
	s-> cy = y;
}

void update_pos_mouse_regle(souris_regle_t *s, int x, int y){
	s-> x = x;
	s-> y = y;
}

void handle_events_regle(SDL_Event *event_regle, lab_t *lab, SDL_Surface *screen){
	int mouseX, mouseY;

	while(SDL_PollEvent(event_regle)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event_regle-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
		}
		if(event_regle-> type == SDL_MOUSEBUTTONDOWN){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_clique_mouse_regle(&lab-> regle.souris, mouseX, mouseY);
		}
		if(event_regle-> type == SDL_MOUSEMOTION){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_mouse_regle(&lab-> regle.souris, mouseX, mouseY);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void boucle_regle(lab_t *lab, SDL_Surface *screen){
	SDL_Event event_regle;
	init_data_regle(&lab-> regle);
	init_graphics_regle(screen, &lab-> regle);
	while(lab-> regle.ouvert == true){
		handle_events_regle(&event_regle, lab, screen);
		verif_regle(&lab-> regle);
		refresh_graphics_regle(screen, &lab-> regle);
		SDL_Delay(100);
	}
}
