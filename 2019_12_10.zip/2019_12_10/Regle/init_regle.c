#include "../general.h"

void init_data_souris_regle(souris_regle_t *s){
	s-> x = -100;
	s-> y = -100;	
	s-> cx = -100;	
	s-> cy = -100;		 
}

void init_data_bouton_regle(bouton_regle_t *b){
	b-> Bouton_des = load_image("ressources/retour_2.bmp");
	b-> Bouton_pas_des = load_image("ressources/retour_1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_REGLE;	
	b-> haut = HAUTEUR_BOUTON_REGLE;

	b-> y = Y_BOUTON_REGLE;
	b-> x = X_BOUTON_REGLE;
}

void init_data_regle(regle_t *r){
	r-> Regle = load_image("ressources/Regle.bmp");

	r-> ouvert = true;

	init_data_bouton_regle(&r-> bouton);
	init_data_souris_regle(&r-> souris);	
}
