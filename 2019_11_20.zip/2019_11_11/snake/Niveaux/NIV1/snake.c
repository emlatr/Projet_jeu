/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

//#include "../../../SDL2_ttf-2.0.15/SDL_ttf.h"


#include "../../../sdl-light.h"
#include "../../../general.h"
#include <time.h>
#include "snake.h"
#include "../../INITIALISATION/init.c"
#include "../../COLLISION/colli.c"
#include "../../COLLISION/colli_entre_eux.c"
#include "../../jeux/update.c"
#include "../../snake_jeu.c"



/**
 * \brief La fonction nettoie les données du monde
 * \param world les données du monde
 */
void clean_data_snake(snake_t *snake){
	SDL_FreeSurface(snake-> background);
	SDL_FreeSurface(snake-> fond);
	SDL_FreeSurface(snake-> PR[NB_POMME].Pomme);
	SDL_FreeSurface(snake-> Serpent);
}





/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du monde
 * \param screen la surface de l'écran de jeu
 * \param world les données du monde
 */
void refresh_graphics_snake(SDL_Surface *screen, snake_t *snake, lab_t *lab){
	apply_surface(snake-> fond, screen, 0, 0);
	apply_surface(snake-> background, screen, 0, 0);
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			apply_surface(snake-> PR[i].Pomme, screen, snake-> PR[i].px, snake-> PR[i].py);
		}
		/*if(snake-> PV[i].exist == 1){
			apply_surface(snake-> PV[i].Pomme, screen, snake-> PV[i].px, snake-> PV[i].py);
		}*/
	}
	apply_surface(snake-> Serpent, screen, snake-> x , snake-> y);
	for(int i = 0; i < snake-> nb_corps; i++){
		apply_surface(snake-> C[i].Corps, screen, snake-> C[i].cx, snake-> C[i].cy);
	}
	if(collision_corps(snake) == 1){
		boucle_snake(lab, screen);
	}
	collision_pomme(snake);
	if(snake-> score >= 20){
		snake-> ouvert = false;
		snake-> score = 0;
	}

	//pomme_pomme(snake);
	
	refresh_surface(screen);
}



/**
 *  \brief programme principal qui implémente la boucle du jeu
 */
void boucle_snake(lab_t *lab, SDL_Surface *screen){
	SDL_Event event2;
	SDL_WM_SetCaption("Fenêtre de jeu de snake !", NULL);
	init_data_snake(&lab-> snake);
	lab->snake.nb_pomme = init_nb_pomme(&lab->snake, 1);
	printf("%i\n", lab->snake.nb_pomme);
	init_data_pomme1(&lab-> snake);
	init_graphics_snake(screen, &lab-> snake);
	while(lab-> snake.ouvert == true){
		handle_events_snake(&event2, &lab-> snake, lab, screen);
		update_data_snake(&lab-> snake);
		refresh_graphics_snake(screen,&lab-> snake, lab);
		SDL_Delay(100);
		if(collision_snake(&lab-> snake)){
			replacement_serpent(&lab-> snake);
		}
	}
	clean_data_snake(&lab-> snake);
	return;
}
