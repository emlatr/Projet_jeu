/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include "../../../sdl-light.h"
#include "../../../general.h"
#include <time.h>
#include "snake5.h"
#include "../../INITIALISATION/init.h"
#include "../../COLLISION/colli.h"
#include "../../jeux/update.h"



/**
 * \brief La fonction nettoie les données du monde
 * \param world les données du monde
 */
void clean_data_snake5(snake_t *snake){
	SDL_FreeSurface(snake-> background);
	SDL_FreeSurface(snake-> fond);
	SDL_FreeSurface(snake-> PR[NB_POMME].Pomme);
	SDL_FreeSurface(snake-> PV[NB_POMME].Pomme);
	//SDL_FreeSurface(snake-> PN[NB_POMME].Pomme);
	SDL_FreeSurface(snake-> PO.Pomme);
	SDL_FreeSurface(snake-> Serpent);
}



void verif3(SDL_Surface *screen, snake_t *snake, lab_t *lab){
	/*for(int i = 0; i< NB_PIERRE; i++){
		apply_surface(snake-> P[i].Pierre, screen, snake-> P[i].pa, snake-> P[i].pb);
		if(collision_corps(snake) == 1 || collision_pierre_serp(snake, &snake->P[i]) == 1){
			boucle_snake5(lab, screen);
		}
	}*/

	apply_surface(snake-> E.Eau, screen, snake-> E.ex, snake-> E.ey);
	
  	collision_pomme(snake);
	
	if(snake-> score >= 40 && snake-> score <= 50 && snake->nb_corps >= 35){
		snake-> ouvert = false;
		snake-> score = 0;
	}

	pomme_pomme(snake);
}
	
	


/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du monde
 * \param screen la surface de l'écran de jeu
 * \param world les données du monde
 */
void refresh_graphics_snake5(SDL_Surface *screen, snake_t *snake, lab_t *lab){
	apply_surface(snake-> fond, screen, 0, 0);
	apply_surface(snake-> background, screen, 0, 0);
	for(int i = 0; i< NB_PIERRE; i++){
		apply_surface(snake-> P[i].Pierre, screen, snake-> P[i].pa, snake-> P[i].pb);
		if(collision_corps(snake) == 1 || collision_pierre_serp(snake, &snake->P[i]) == 1){
			boucle_snake5(lab, screen);
		}
	}
	verif3(screen, snake, lab);
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			apply_surface(snake-> PR[i].Pomme, screen, snake-> PR[i].px, snake-> PR[i].py);
		}
		if(snake-> PV[i].exist == 1){
			apply_surface(snake-> PV[i].Pomme, screen, snake-> PV[i].px, snake-> PV[i].py);
		}
		if(snake-> PN[i].exist == 1){
			apply_surface(snake-> PN[i].Pomme, screen, snake-> PN[i].px, snake-> PN[i].py);
		}
	}

	apply_surface(snake-> Serpent, screen, snake-> x , snake-> y);
	apply_surface(snake-> PO.Pomme, screen, snake-> PO.px, snake-> PO.py);
	
	for(int i = 0; i < snake-> nb_corps; i++){
		apply_surface(snake-> C[i].Corps, screen, snake-> C[i].cx, snake-> C[i].cy);
	}
	
	//verif2(screen, snake, lab);
	
	refresh_surface(screen);
}



/**
 *  \brief programme principal qui implémente la boucle du jeu
 */
void boucle_snake5(lab_t *lab, SDL_Surface *screen){
	SDL_Event event2;
	SDL_WM_SetCaption("Fenêtre de jeu de snake, niveau 5 !", NULL);
	init_eau(screen, &lab->snake);
	init_data_snake3_4(&lab-> snake);
	lab->snake.nb_pomme = init_nb_pomme(&lab->snake, 5);
	printf("%i\n", lab->snake.nb_pomme);
	init_data_pomme(&lab-> snake);
	init_data_pomme_or(screen, &lab-> snake);
	init_pierre(screen,&lab->snake);
	init_timer(&lab->snake);
	init_graphics_snake2(screen, &lab-> snake);
	while(lab-> snake.ouvert == true){
		if(collision_eau_serp(&lab-> snake, &lab-> snake.E) != 1){
			handle_events_snake(&event2, &lab-> snake, lab, screen);
		}
		update_data_snake(&lab-> snake);
		update_timer(&lab-> snake);
		refresh_graphics_snake5(screen,&lab-> snake, lab);
		SDL_Delay(100);
		if(collision_snake(&lab-> snake)){
			replacement_serpent(&lab-> snake);
		}
	}
	//clean_data_snake5(&lab-> snake);
	return;
}
