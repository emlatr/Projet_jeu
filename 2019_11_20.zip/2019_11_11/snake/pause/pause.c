#include "../../general.h"


////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_pause(SDL_Surface *screen, pause_t *p){
	apply_surface(p-> Pause, screen, 0, 0);
	refresh_surface(screen);
}

///////////////////////////////////////////////////////////////////////////////////////

void handle_events_pause(SDL_Event *event_pause, lab_t *lab, SDL_Surface *screen){
	Uint8 *keystates;
	while(SDL_PollEvent(event_pause)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event_pause-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
			lab->snake.pause.ouvert = false;
		}
		/* gestion des evenements clavier */
		keystates = SDL_GetKeyState(NULL);
		/* Si l'utilisateur appuie sur les flèches, le personnage se déplace */
		if(keystates[SDLK_p])
		{
			lab->snake.pause.ouvert = false;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void boucle_pause(lab_t *lab, SDL_Surface *screen){
	SDL_Event event_pause;
	init_data_pause(&lab->snake.pause);
	while(lab->snake.pause.ouvert == true){
		handle_events_pause(&event_pause, lab, screen);
		refresh_graphics_pause(screen,&lab->snake.pause);
		SDL_Delay(100);
	}
}
