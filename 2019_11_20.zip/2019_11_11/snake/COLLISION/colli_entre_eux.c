/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */



#include "colli.h"

int colli_pomme_pomme(pomme_t *p1, pomme_t *p2){
	if( (p1-> px + SIZE_RIGHT_POMME >= p2-> px + SIZE_LEFT_POMME ) && (p1-> px + SIZE_LEFT_POMME <= p2-> px + SIZE_RIGHT_POMME ) ){
		if( (p1-> py + SIZE_POMME >= p2-> py + SIZE_LEFT_POMME ) && (p1-> py <= p2-> py + SIZE_POMME ) ){
			return 1;
		}
	}
	return 0;
}
