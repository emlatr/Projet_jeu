#ifndef INIT_REGLE_H
#define INIT_REGLE_H

#include "../sdl-light.h"

void init_data_souris_regle(souris_regle_t *s);

void init_data_bouton_regle(bouton_regle_t *b);

void init_data_regle(regle_t *r);

#endif
