/**
 * \file init_lab.h
 * \author BONTE Emeline, DEBART Arthur
 * \version final
 * \date 11 decembre 2019
 */
#ifndef INIT_LAB_H
#define INIT_LAB_H

/**
 * \brief La fonction initialise les données du monde du jeu
 * \param lab les données du monde
 */
void init_data(lab_t *lab);

/**
 * \brief La fonction initialise les coffres
 * \param lab les données du monde
 */
void init_coffre(lab_t *lab);

/**
 * \brief La fonction initialise le monstre
 * \param lab les données du monde
 */
void init_monstre(lab_t *lab);

/**
 * \brief La fonction initialise les données des murs
 * \param lab les données du monde
 */
void init_mur(lab_t * lab);

/**
 * \brief La fonction initialise les transparences des différentes surfaces
 * \param screen la surface correspondant à l'écran de jeu
 * \param lab les données du monde
 */
void init_graphics(SDL_Surface *screen, lab_t *lab);

#endif
