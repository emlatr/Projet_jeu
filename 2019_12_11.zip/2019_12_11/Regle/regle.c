/**
 * \file regle.c
 * \brief Programme du menu 'règles du jeu'
 * \author BONTE Emeline, DEBART Arthur
 * \version fini
 * \date 11 decembre 2019
 */

//#include "../general.h"
#include "regle.h"


/**
 * \brief La fonction initialise les données du bouton dans le menu 'règles du jeu'
 * \param b les données du bouton dans les règles du jeu
 * \param screen la surface correspondant à l'écran de jeu
 */
void init_graphic_regle_bouton(SDL_Surface *screen, bouton_regle_t *b){
	set_transparence(screen, b-> Bouton_des, 255, 255, 255);
	set_transparence(screen, b-> Bouton_pas_des, 255, 255, 255);
}

/**
 * \brief La fonction initialise les données du menu 'règles du jeu'
 * \param r les données du menu 'règles du jeu'
 * \param screen la surface correspondant à l'écran de jeu
 */
void init_graphics_regle(SDL_Surface *screen, regle_t *r){
	init_graphic_regle_bouton(screen, &r-> bouton);
		
}

////////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du bouton dans les règles du jeu
 * \param screen la surface de l'écran de jeu
 * \param b les données du bouton dans les règles du jeu
 */
void refresh_graphics_regle_bouton(SDL_Surface *screen, bouton_regle_t *b){
	apply_surface(b-> Bouton, screen, b-> x, b-> y);
}

/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du menu 'règles du jeu'
 * \param screen la surface de l'écran de jeu
 * \param r les données du menu 'règles du jeu'
 */
void refresh_graphics_regle(SDL_Surface *screen, regle_t *r){
	apply_surface(r-> Regle, screen, 0, 0);
	refresh_graphics_regle_bouton(screen, &r-> bouton);	
	refresh_surface(screen);
}

//////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction vérifie la position de la souris sur le bouton dans les règles du jeu
 * \param b les données du bouton dans les règles du jeu
 * \param s les données de la souris dans les règles du jeu
 */
void verif_pos_souris_regle_bouton(bouton_regle_t *b, souris_regle_t *s){
	if((s-> x >= b-> x) && (s-> x <= b-> x + b-> larg)){
		if((s-> y >= b-> y) && (s-> y <= b-> y + b-> haut)){
			b-> Bouton = b-> Bouton_des;
			return;
		}
	}
	b-> Bouton = b-> Bouton_pas_des;
}

///////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction vérifie si on clique sur le bouton dans les règles du jeu
 * \param b les données du bouton dans les règles du jeu
 * \param s les données de la souris dans les règles du jeu
 * \param r les données du menu 'règles du jeu'
 */
void verif_clique_souris_regle_bouton(bouton_regle_t *b, souris_regle_t *s, regle_t *r){
	if((s-> cx >= b-> x) && (s-> cx <= b-> x + b-> larg)){
		if((s-> cy >= b-> y) && (s-> cy <= b-> y + b-> haut)){
			r-> ouvert = false;
		}
	}
}

/**
 * \brief La fonction vérifie les cliques et la position de la souris sur le bouton dans les règles du jeu
 * \param r les données du menu 'règles du jeu'
 */
void verif_regle(regle_t *r){
	verif_pos_souris_regle_bouton(&r-> bouton, &r-> souris);
	verif_clique_souris_regle_bouton(&r-> bouton, &r-> souris, r);
}

//////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction vérifie si on clique dans les regles
 * \param s les données de la souris dans les règles du jeu
 * \param x position de la souris en x 
 * \param y position de la souris en y
 */
void update_clique_mouse_regle(souris_regle_t *s, int x, int y){
	s-> cx = x;
	s-> cy = y;
}

/**
 * \brief La fonction vérifie la position si on clique dans les regles
 * \param s les données de la souris dans les règles du jeu
 * \param x position de la souris en x 
 * \param y position de la souris en y
 */
void update_pos_mouse_regle(souris_regle_t *s, int x, int y){
	s-> x = x;
	s-> y = y;
}

/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event_regle paramètre qui contient les événements des regles
 * \param lab les données du monde
 * \param screen la surface de l'écran de jeu
 */
void handle_events_regle(SDL_Event *event_regle, lab_t *lab, SDL_Surface *screen){
	int mouseX, mouseY;

	while(SDL_PollEvent(event_regle)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event_regle-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
		}
		if(event_regle-> type == SDL_MOUSEBUTTONDOWN){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_clique_mouse_regle(&lab-> regle.souris, mouseX, mouseY);
		}
		if(event_regle-> type == SDL_MOUSEMOTION){
			SDL_GetMouseState(&mouseX, &mouseY);
			update_pos_mouse_regle(&lab-> regle.souris, mouseX, mouseY);
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief La fonction implémente la boucle des regles du jeu
 * \param lab les données du monde
 * \param screen la surface de l'écran de jeu
 */
void boucle_regle(lab_t *lab, SDL_Surface *screen){
	SDL_Event event_regle;
	init_data_regle(&lab-> regle);
	init_graphics_regle(screen, &lab-> regle);
	while(lab-> regle.ouvert == true){
		handle_events_regle(&event_regle, lab, screen);
		verif_regle(&lab-> regle);
		refresh_graphics_regle(screen, &lab-> regle);
		SDL_Delay(100);
	}
}
