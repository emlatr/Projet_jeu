/**
 * \file regle.h
 * \author BONTE Emeline, DEBART Arthur
 * \version fini
 * \date 11 decembre 2019
 */

#ifndef REGLE_H
#define REGLE_H

#include "../sdl-light.h"

void init_data_souris_regle(souris_regle_t *s);

void init_data_bouton_regle(bouton_regle_t *b);

void init_data_regle(regle_t *r);

//////////////////////////////////////////////////////////////////////////////////////////

void init_graphic_regle_bouton(SDL_Surface *screen, bouton_regle_t *b);

void init_graphics_regle(SDL_Surface *screen, regle_t *r);

void refresh_graphics_regle_bouton(SDL_Surface *screen, bouton_regle_t *b);

void refresh_graphics_regle(SDL_Surface *screen, regle_t *r);

void verif_pos_souris_regle_bouton(bouton_regle_t *b, souris_regle_t *s);

void verif_clique_souris_regle_bouton(bouton_regle_t *b, souris_regle_t *s, regle_t *r);

void verif_regle(regle_t *r);

void update_clique_mouse_regle(souris_regle_t *s, int x, int y);

void update_pos_mouse_regle(souris_regle_t *s, int x, int y);

void handle_events_regle(SDL_Event *event_regle, lab_t *lab, SDL_Surface *screen);

void boucle_regle(lab_t *lab, SDL_Surface *screen);

#endif
