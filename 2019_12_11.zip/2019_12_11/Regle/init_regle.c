/**
 * \file init_regle.c
 * \brief Programme d'initialisation du menu 'règles du jeu'
 * \author BONTE Emeline, DEBART Arthur
 * \version fini
 * \date 11 decembre 2019
 */

#include "../general.h"

/**
 * \brief La fonction initialise la position de la souris dans les règles du jeu 
 * \param s les données de la souris dans les règles du jeu 
 */
void init_data_souris_regle(souris_regle_t *s){
	s-> x = -100;
	s-> y = -100;	
	s-> cx = -100;	
	s-> cy = -100;		 
}

/**
 * \brief La fonction initialise le bouton de retour vers le menu
 * \param b les données du bouton dans les règles du jeu
 */
void init_data_bouton_regle(bouton_regle_t *b){
	b-> Bouton_des = load_image("ressources/retour_2.bmp");
	b-> Bouton_pas_des = load_image("ressources/retour_1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_REGLE;	
	b-> haut = HAUTEUR_BOUTON_REGLE;

	b-> y = Y_BOUTON_REGLE;
	b-> x = X_BOUTON_REGLE;
}

/**
 * \brief La fonction initialise le menu 'règles du jeu'
 * \param r les données du menu 'règles du jeu'
 */
void init_data_regle(regle_t *r){
	r-> Regle = load_image("ressources/Regle.bmp");

	r-> ouvert = true;

	init_data_bouton_regle(&r-> bouton);
	init_data_souris_regle(&r-> souris);	
}
