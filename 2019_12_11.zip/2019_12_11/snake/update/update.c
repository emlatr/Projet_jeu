/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include "../../sdl-light.h"
#include <time.h>
#include "update.h"
#include "../INITIALISATION/init.h"
#include "../COLLISION/colli.h"



/**
 * \brief La fonction met à jour les données du serpent
 * \param world les données du monde
 */
void update_serp(snake_t *snake){
	for(int i = snake-> nb_corps-1; i>0; i--){
		snake-> C[i].cx = snake-> C[i-1].cx;
		snake-> C[i].cy = snake-> C[i-1].cy;
	}
	snake-> C[0].cx = snake-> x;
	snake-> C[0].cy = snake-> y;
	if(snake-> direct == 0 ){
		snake-> x += snake-> vx;
	}
	else if(snake-> direct == 1){
		snake-> y += snake-> vy;
	}
	else if(snake-> direct == 2){
		snake->x -= snake->vx;
	}
	else if(snake-> direct == 3){
		snake-> y -= snake-> vy;
	}
}

void update_timer(snake_t *snake){
	srand((unsigned)time(NULL));
	snake->T.TM = SDL_GetTicks();
	switch (snake->T.L){
	case 1 :
		if(snake->T.TM - snake->T.TA >= snake->T.EA){
			snake->T.TA = SDL_GetTicks();
			snake->PO.px = rand() % 820 + 0;
			snake->PO.py = rand() % 420 + 0;
			snake->T.L = 2;
		}
		break;
	case 2 :
		if(snake->T.TM - snake->T.TA >= snake->T.ER){
			snake->T.TA = SDL_GetTicks();
			snake->PO.px = -100;
			snake->PO.py = -100;
			snake->T.L = 1;
		}
		break;
	}
}


/**
 * \brief La fonction met à jour les données en tenant compte de la physique du monde
 * \param les données du monde
 */
void update_data_snake(snake_t *snake){
	update_serp(snake);
}

/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event paramètre qui contient les événements
 * \param world les données du monde
 */
void handle_events_snake(SDL_Event *event2, snake_t *snake, lab_t *lab, SDL_Surface *screen){
	Uint8 *keystates;
	while(SDL_PollEvent(event2)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event2-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
			snake-> ouvert = false;
		}
		/* gestion des evenements clavier */
		keystates = SDL_GetKeyState(NULL);
		/* Si l'utilisateur appuie sur les flèches, le personnage se déplace */
		if(keystates[SDLK_z])
		{
			snake-> direct = 3;
		}
		else if(keystates[SDLK_s])
		{
			snake-> direct = 1;
		}
		else if(keystates[SDLK_d])
		{
			snake-> direct = 0;
		}
		else if(keystates[SDLK_q])
		{
			snake-> direct = 2;
		}
		else if(keystates[SDLK_p])
		{
			boucle_pause(lab, screen);
		}
	}
}
