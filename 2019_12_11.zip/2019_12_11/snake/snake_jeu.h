/**
 * \file snake_jeu.h
 * \author BONTE Emeline, DEBART Arthur
 * \version final
 * \date 11 decembre 2019
 */


#ifndef SNAKEJEU_H
#define SNAKEJEU_H

void pomme_new(snake_t *snake, int i);

int collision_pomme(snake_t *snake);

void pomme_pomme(snake_t *snake);

int collision_pomme_pierre(snake_t *snake);

#endif
