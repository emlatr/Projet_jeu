/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include "../../sdl-light.h"
#include "../../general.h"
#include <time.h>
#include "snake.h"
#include "../INITIALISATION/init.h"
#include "../COLLISION/colli.h"

#include "../resultat/gagner_perdu.h"

#include "../pause/pause.h"
#include "../update/update.h"





/**
 * \brief La fonction nettoie les données du monde
 * \param world les données du monde
 */
void clean_data_snake4(snake_t *snake){
	//printf("bonjour\n");
	SDL_FreeSurface(snake-> background);
	//printf("bonjour\n");
	SDL_FreeSurface(snake-> fond);
	//printf("bonjour\n");
	SDL_FreeSurface(snake-> PR[NB_POMME].Pomme);
	//printf("bonjour\n");
	SDL_FreeSurface(snake-> PV[NB_POMME].Pomme);
	//printf("bonjour\n");
	//SDL_FreeSurface(snake-> PN[NB_POMME].Pomme);
	SDL_FreeSurface(snake-> PO.Pomme);
	//printf("bonjour\n");
	SDL_FreeSurface(snake-> Serpent);
	//printf("bonjour\n");
}


void verif2(SDL_Surface *screen, snake_t *snake, lab_t *lab){
	//for(int i = 0; i< NB_PIERRE; i++){
		//apply_surface(snake-> P[i].Pierre, screen, snake-> P[i].pa, snake-> P[i].pb);
		
	//}

	apply_surface(snake-> E.Eau, screen, snake-> E.ex, snake-> E.ey);
	
  	collision_pomme(snake);
	
	if(snake-> score >= 40 && snake-> score <= 50 && snake->nb_corps >= 35){
		boucle_gagner(lab,screen);
		snake-> ouvert = false;
		snake-> score = 0;
	}

	//pomme_pomme(snake);
}
	
	


/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du monde
 * \param screen la surface de l'écran de jeu
 * \param world les données du monde
 */
void refresh_graphics_snake4(SDL_Surface *screen, snake_t *snake, lab_t *lab){
	apply_surface(snake-> fond, screen, 0, 0);
	apply_surface(snake-> background, screen, 0, 0);
	verif2(screen, snake, lab);
	if(collision_corps(snake) == 1 ){
		boucle_perdu(lab,screen);
		boucle_snake4(lab, screen);
	}
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			apply_surface(snake-> PR[i].Pomme, screen, snake-> PR[i].px, snake-> PR[i].py);
		}
		if(snake-> PV[i].exist == 1){
			apply_surface(snake-> PV[i].Pomme, screen, snake-> PV[i].px, snake-> PV[i].py);
		}
		if(snake-> PN[i].exist == 1){
			apply_surface(snake-> PN[i].Pomme, screen, snake-> PN[i].px, snake-> PN[i].py);
		}
	}

	apply_surface(snake-> Serpent, screen, snake-> x , snake-> y);
	apply_surface(snake-> PO.Pomme, screen, snake-> PO.px, snake-> PO.py);
	
	for(int i = 0; i < snake-> nb_corps; i++){
		apply_surface(snake-> C[i].Corps, screen, snake-> C[i].cx, snake-> C[i].cy);
	}
	
	
	refresh_surface(screen);
}



/**
 *  \brief programme principal qui implémente la boucle du jeu
 */
void boucle_snake4(lab_t *lab, SDL_Surface *screen){
	SDL_Event event2;
	SDL_WM_SetCaption("Fenêtre de jeu de snake, niveau 4 !", NULL);
	init_eau(screen, &lab->snake);
	init_data_snake3_4(&lab-> snake);
	lab->snake.nb_pomme = init_nb_pomme(&lab->snake, 4);
	init_data_pomme(&lab-> snake);
	init_data_pomme_or(screen, &lab-> snake);
	init_graphics_snake2(screen, &lab-> snake);
	printf("Vous devez obtenir 40 points et avoir un nombre de corps compris entre 35 et 50 pour terminer la partie ! \n");
	while(lab-> snake.ouvert == true){
		if(collision_eau_serp(&lab-> snake, &lab-> snake.E) != 1){
			handle_events_snake(&event2, &lab-> snake, lab, screen);
		}
		update_data_snake(&lab-> snake);
		//update_timer(&lab-> snake);
		refresh_graphics_snake4(screen,&lab-> snake, lab);
		SDL_Delay(100);
		if(collision_snake(&lab-> snake)){
			replacement_serpent(&lab-> snake);
		}
	}
	return;
}
