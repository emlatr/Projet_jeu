#ifndef GAGNER_H
#define GAGNER_H

#include "../sdl-light.h"

void refresh_graphics_gagner(SDL_Surface *screen, resultat_t *r);

void handle_events_gagner(SDL_Event *event_gagne, lab_t *lab, SDL_Surface *screen);

void boucle_gagner(lab_t *lab, SDL_Surface *screen);

#endif
