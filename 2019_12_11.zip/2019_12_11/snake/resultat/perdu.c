//#include "../../general.h"
#include "gagner_perdu.h"

////////////////////////////////////////////////////////////////////////////////////////

void refresh_graphics_perdu(SDL_Surface *screen, resultat_t *r){
	apply_surface(r-> Perdu, screen, 0, 0);
	refresh_surface(screen);
}

///////////////////////////////////////////////////////////////////////////////////////

void handle_events_perdu(SDL_Event *event_perdu, lab_t *lab, SDL_Surface *screen){
	Uint8 *keystates;
	while(SDL_PollEvent(event_perdu)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event_perdu-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
			lab->snake.perdu.ouvert_perdu = false;
		}
		/* gestion des evenements clavier */
		keystates = SDL_GetKeyState(NULL);
		/* Si l'utilisateur appuie sur les flèches, le personnage se déplace */
		if(keystates[SDLK_ESCAPE])
		{
			lab->snake.perdu.ouvert_perdu = false;
		}
	}
}

/////////////////////////////////////////////////////////////////////////////////////

void boucle_perdu(lab_t *lab, SDL_Surface *screen){
	SDL_Event event_perdu;
	init_data_resultat(&lab->snake.perdu, screen);
	while(lab->snake.perdu.ouvert_perdu == true){
		handle_events_perdu(&event_perdu, lab, screen);
		refresh_graphics_perdu(screen,&lab->snake.perdu);
		SDL_Delay(100);
	}
}
