/**
 * \file init_menu.h
 * \author BONTE Emeline, DEBART Arthur
 * \version final
 * \date 11 decembre 2019
 */

#ifndef INIT_MENU_H
#define INIT_MENU_H

#include "../sdl-light.h"

void init_data_souris_menu(souris_t *s);

void init_data_bouton_menu_1(bouton_menu_t *b, int x);

void init_data_bouton_menu_2(bouton_menu_t *b, int x);

void init_data_bouton_menu_i(bouton_menu_t *b, int x, int i);

void init_data_menu(menu_t *m);

#endif
