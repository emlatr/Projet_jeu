/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version fini
 * \date 11 decembre 2019
 */

#include "general.h"
#include "Menu/init_menu.c"
#include "Menu/menu.c"
#include "Regle/init_regle.c"
#include "Regle/regle.c"
#include "Lab/collision/colli_lab.c"
#include "Lab/initialisation/init_lab.c"

/**
 * \brief La fonction met à jour les données du monstre
 * \param lab les données du monde
 */
void update_monstre(lab_t *lab){
	if(lab->monstre.direct == 0)
		lab->monstre.my += lab->monstre.vmy;
	else if(lab->monstre.direct == 1)
		lab->monstre.my -= lab->monstre.vmy;
}


/**
 * \brief La fonction nettoie les données du monde
 * \param lab les données du monde
 */
void clean_data(lab_t *lab){
	SDL_FreeSurface(lab->background);
	SDL_FreeSurface(lab->Lampe);
	SDL_FreeSurface(lab->Jean);
	SDL_FreeSurface(lab->Jean2);
	SDL_FreeSurface(lab->Jean3);
	SDL_FreeSurface(lab->Jean4);
	SDL_FreeSurface(lab->monstre.Monstre);
}



/**
 * \brief La fonction indique si le jeu est fini en fonction des données du monde
 * \param lab les données du monde
 * \return 1 si le jeu est fini, 0 sinon
 */
int is_game_over(lab_t *lab){
	return lab->gameover;
}

/**
 * \brief La fonction applique la surface de l'image de fond à quatre positions différentes sur l'écran de jeu, de sorte de complètement couvrir ce dernier
 * \param screen l'écran de jeu
 * \param bg la surface de l'image de fond
 */
void apply_background(SDL_Surface *bg, SDL_Surface *screen){
	apply_surface(bg,screen,0,0);
}

/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du monde
 * \param screen la surface de l'écran de jeu
 * \param lab les données du monde
 */
void refresh_graphics(SDL_Surface *screen, lab_t *lab){
	apply_background(lab->background,screen);
	apply_surface(lab->Jean, screen, lab->x , lab->y);
	for(int i = 0; i< NB_COFFRE; i++){
		if(lab-> Co[i].exist == 1){
			apply_surface(lab->Co[i].Coffre, screen, lab->Co[i].cx, lab->Co[i].cy);
		}
	}
	apply_surface(lab->monstre.Monstre, screen, lab->monstre.mx, lab->monstre.my);
	apply_surface(lab->Lampe, screen, lab->x-1480, lab->y - 1500);
	apply_surface(lab->intero, screen, lab->Co[0].cx-5, lab->Co[0].cy-8);

	colli_monstre_Jean(lab);
	colli_mur_monstre(lab);
	if(lab->y < 0){
		lab->y = 0;
	}

	refresh_surface(screen);
}

/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event paramètre qui contient les événements
 * \param lab les données du monde
 * \param screen la surface de l'écran de jeu
 */
void handle_events(SDL_Event *event,lab_t *lab, SDL_Surface* screen){
	Uint8 *keystates;
	while( SDL_PollEvent( event ) ) {
	//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
		  	//On quitte le programme
			lab->gameover = 1;
		}
		/* gestion des evenements clavier */
		keystates = SDL_GetKeyState( NULL );
		if(keystates[SDLK_e]){
			collision_coffre_Jean(lab, screen);
		}
		/* Si l'utilisateur appuie sur z,q,s,d , le personnage se déplace */
		if(keystates[SDLK_z])
		{
			lab->deplace = 0;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean4;
				lab->Lampe = lab->Lampe_haut;
				lab->y-=10;
			}

		}
		else if(keystates[SDLK_s])
		{
			lab->deplace = 1;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean1;
				lab->Lampe = lab->Lampe_bas;
				lab->y+=10;
			}
		}
		else if(keystates[SDLK_d])
		{
			lab->deplace = 2;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean2;
				lab->Lampe = lab->Lampe_droite;
				lab->x+=10;
			}
		}
		else if(keystates[SDLK_q])
		{
			lab->deplace = 3;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean3;
				lab->Lampe = lab->Lampe_gauche;
				lab->x-=10;
			}
		}
	}
}

/**
 *  \brief programme principal qui implémente la boucle du jeu
 */
int main( int argc, char* args[] )
{
	SDL_Event event;
	lab_t lab;
	SDL_Surface *screen;
	screen = init_sdl(SCREEN_WIDTH, SCREEN_HEIGHT);
	boucle_menu(&lab, screen);
	SDL_WM_SetCaption("Fenêtre de jeu de labyrinthe !", NULL);
	init_data(&lab);
	init_mur(&lab);
	init_graphics(screen,&lab);
	//active la répétition des touches
	SDL_EnableKeyRepeat(100, 100); //en restant appuyé sur une touche le personnage bouge encore
	while(!is_game_over(&lab)){
		SDL_WM_SetCaption("Fenêtre de jeu de labyrinthe !", NULL);
		/*déplace le personnage d'un mur à l'autre */
		collision_teleportation(&lab);
		update_monstre(&lab);
		handle_events(&event,&lab, screen);
		refresh_graphics(screen,&lab);
		SDL_Delay(10);
			
	}
	clean_data(&lab);
	quit_sdl();
	return 0;
}
