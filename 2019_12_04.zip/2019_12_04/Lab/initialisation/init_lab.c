/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include "init_lab.h"

/**
 * \brief La fonction initialise les données du monde du jeu
 * \param lab les données du monde
 */
void init_data(lab_t *lab){ 
	lab-> background = load_image( "ressources/labyrinthe3.bmp" );
	lab-> Lampe = load_image( "ressources/pixil-frame-0(2).bmp" );
	lab-> Lampe_droite = load_image( "ressources/pixil-frame-0(3).bmp" );
	lab-> Lampe_gauche = load_image( "ressources/pixil-frame-0(4).bmp" );
	lab-> Lampe_haut = load_image( "ressources/pixil-frame-0(5).bmp" );
	lab-> Lampe_bas = load_image( "ressources/pixil-frame-0(2).bmp" );
	lab-> intero  = load_image( "ressources/point.bmp" );
	lab-> gameover = 0;
	lab-> Jean4 = load_image( "ressources/Jean_dos2.bmp");
	lab-> Jean3 = load_image( "ressources/Jean_cote_gauche2.bmp");
	lab-> Jean2 = load_image( "ressources/Jeancopie.bmp");
	lab-> Jean1 = load_image( "ressources/Jean_face2.bmp");
	lab-> Jean = load_image( "ressources/Jean_face2.bmp");//Le premier pers
	lab-> x = 0.;
	lab-> y = 0.;
	lab->deplace = 1;
	init_coffre(lab);
	init_monstre(lab);
}

void init_coffre(lab_t *lab){ 
	for(int i = 0; i<NB_COFFRE; i++){
		lab->Co[i].Coffre = load_image("ressources/coffre.bmp");
		lab->Co[i].cx = i + i*2;
		lab->Co[i].cy = i + i*2;
		lab->Co[i].exist = 1;
	}
	lab->Co[0].cx = 4 + 12;
	lab->Co[0].cy = 532 - 4 - 14;

	lab->Co[1].cx = 264 + 4 + 12;
	lab->Co[1].cy = 532 - 4 - 14;

	lab->Co[2].cx = 264 + 4 + 12;
	lab->Co[2].cy = 4;

	lab->Co[3].cx = 396 + 4 + 12;
	lab->Co[3].cy = 176 - 14;

	lab->Co[4].cx = 396 + 4 + 12;
	lab->Co[4].cy = 532 - 4 - 14;
}


void init_monstre(lab_t *lab){
	lab->monstre.Monstre = load_image("ressources/monstre.bmp");
	lab->monstre.Monstreface = load_image("ressources/monstre.bmp");
	lab->monstre.Monstredos = load_image("ressources/monstre_dos.bmp");
	lab->monstre.mx = 264 - 5;//lab->M[42].x;
	lab->monstre.my = 88 - 30 ;//lab->M[42].y;
	lab->monstre.vmx = 0.5;
	lab->monstre.vmy = 0.5;
	lab->monstre.direct = 0;
}


/**
 * \brief La fonction initialise les données des murs
 * \param lab les données du monde
 */
void init_mur(lab_t * lab){ 
	lab->M[0].x = 0;
	lab->M[0].y = 0;
	lab->M[0].larg = 4;
	lab->M[0].haut = 532;
	
	lab->M[1].x = 0;
	lab->M[1].y = 528;
	lab->M[1].larg = 532;
	lab->M[1].haut = 4;
	
	lab->M[2].x = 528;
	lab->M[2].y = 0;
	lab->M[2].larg = 4;
	lab->M[2].haut = 532;
	
	lab->M[3].x = 44;
	lab->M[3].y = 0;
	lab->M[3].larg = 488;
	lab->M[3].haut = 4;
	
	int i;
	for(i = 4; i<33; i++){
		lab->M[i].larg = 4;
	}
	
	for(i = 4; i<6; i++){
		lab->M[i].x = 44;
	}
	
	for(i = 6; i<9; i++){
		lab->M[i].x = 88;
	}
	
	for(i = 9; i<13; i++){
		lab->M[i].x = 132;
	}
	
	for(i = 13; i<18; i++){
		lab->M[i].x = 176;
	}
 
	for(i = 18; i<20; i++){
		lab->M[i].x = 220;
	}

	for(i = 20; i<22; i++){
		lab->M[i].x = 264;
	}

	for(i = 22; i<25; i++){
		lab->M[i].x = 308;
	}
	
	for(i = 25; i<27; i++){
		lab->M[i].x = 352;
	}
	
	lab->M[27].x = 396;
	lab->M[27].y = 44;
	lab->M[27].haut = 488;
	
	for(i = 28; i<31; i++){
		lab->M[i].x = 440;
	}
	
	for(i = 31; i<33; i++){
		lab->M[i].x = 484;
	}
	
	for(i = 13; i<16; i++){
		lab->M[i].haut = 48;
	}
	
	for(i = 16; i<19; i++){
		lab->M[i].haut = 92;
	}
	
	lab->M[4].y = 0;
	lab->M[4].haut = 136;
	
	lab->M[5].y = 176;
	lab->M[5].haut = 356;
	
	lab->M[6].y = 0;
	lab->M[6].haut = 48;
	
	lab->M[7].y = 88;
	lab->M[7].haut = 92;
	
	lab->M[8].y = 264;
	lab->M[8].haut = 224;
	
	lab->M[9].y = 0;
	lab->M[9].haut = 136;
	
	lab->M[10].y = 176;
	lab->M[10].haut = 92;
	
	lab->M[11].y = 308;
	lab->M[11].haut = 48;
	
	lab->M[12].y = 396;
	lab->M[12].haut = 136;
	
	lab->M[13].y = 0;
		
	lab->M[14].y = 88;

	lab->M[15].y = 176;
	
	lab->M[16].y = 264;
	
	lab->M[17].y = 396;
	
	lab->M[18].y = 0;
	
	lab->M[19].y = 176;
	lab->M[19].haut = 312;
	
	lab->M[20].y = 0;
	lab->M[20].haut = 268;
	
	lab->M[21].y = 308;
	lab->M[21].haut = 224;
	
	lab->M[22].y = 0;
	lab->M[22].haut = 136;
	
	lab->M[23].y = 176;
	lab->M[23].haut = 48;
	
	lab->M[24].y = 264;
	lab->M[24].haut = 268;
	
	lab->M[25].y = 0;
	lab->M[25].haut = 312;
	
	lab->M[26].y = 352;
	lab->M[26].haut = 136;

	lab->M[28].y = 0;
	lab->M[28].haut = 48;
	
	lab->M[29].y = 88;
	lab->M[29].haut = 92;
	
	lab->M[30].y = 352;
	lab->M[30].haut = 180;
	
	lab->M[31].y = 0;
	lab->M[31].haut = 136;
	
	lab->M[32].y = 176;
	lab->M[32].haut = 312;
	
	for(i = 33; i<52; i++){
		lab->M[i].haut = 4;
	}
	
	for(i = 33; i<52; i++){
		lab->M[i].larg = 48;
	}
	
	lab->M[34].larg = 92;
	lab->M[36].larg = 92;
	lab->M[51].larg = 92;
	
	for(i = 36; i<41; i++){
		lab->M[i].x = 132;
	}
	
	lab->M[38].x = 176;
	
	lab->M[33].x = 44;
	lab->M[33].y = 132;
	
	lab->M[34].x = 44;
	lab->M[34].y = 220;
	
	lab->M[35].x = 88;
	lab->M[35].y = 264;
	
	lab->M[36].y = 132;	
	
	lab->M[37].y = 172;

	lab->M[38].y = 264;

	lab->M[39].y = 352;

	lab->M[40].y = 396;
	
	lab->M[41].x = 264;
	lab->M[41].y = 88;
	
	lab->M[42].x = 308;
	lab->M[42].y = 172;
	
	lab->M[43].x = 220;
	lab->M[43].y = 308;
	
	lab->M[44].x = 264;
	lab->M[44].y = 352;
	
	lab->M[45].x = 396;
	lab->M[45].y = 88;
	
	lab->M[46].x = 396;
	lab->M[46].y = 172;
	
	lab->M[47].x = 484;
	lab->M[47].y = 172;
	
	lab->M[48].x = 440;
	lab->M[48].y = 220;
	
	lab->M[49].x = 396;
	lab->M[49].y = 264;
	
	lab->M[50].x = 440;
	lab->M[50].y = 308;
	
	lab->M[51].x = 352;
	lab->M[51].y = 352;
}
 

/**
 * \brief La fonction initialise les transparences des différentes surfaces
 * \param screen la surface correspondant à l'écran de jeu
 * \param lab les données du monde
 */
void init_graphics(SDL_Surface *screen, lab_t *lab){
	set_transparence(screen, lab->intero, 255,255,255);
	set_transparence(screen, lab->Lampe, 255,255,255);
	set_transparence(screen, lab->Lampe_droite, 255,255,255);
	set_transparence(screen, lab->Lampe_gauche, 255,255,255);
	set_transparence(screen, lab->Lampe_bas, 255,255,255);
	set_transparence(screen, lab->Lampe_haut, 255,255,255);
	set_transparence(screen, lab->Jean, 255,255,255);
	set_transparence(screen, lab->Jean1, 255,255,255);
	set_transparence(screen, lab->Jean2, 255,255,255);
	set_transparence(screen, lab->Jean3, 255,255,255);
	set_transparence(screen, lab->Jean4, 255,255,255);
	for(int i = 0; i<NB_COFFRE;i++){
		set_transparence(screen, lab->Co[i].Coffre, 255,255,255);
	}
	set_transparence(screen, lab->monstre.Monstre, 255,255,255);
	set_transparence(screen, lab->monstre.Monstreface, 255,255,255);
	set_transparence(screen, lab->monstre.Monstredos, 255,255,255);
}
 
