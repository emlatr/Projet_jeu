/**
 * \file general.h
 * \brief Programme general pour toutes les valeurs stables et les structures
 * \author Emeline BONTE, Arthur DEBART
 * \version 0.1
 * \date 21 mars 2019-27 mai 2019
 */

#include "../sdl-light.h"
#include "pause/general_pause.h"
#include "resultat/general_resultat.h"
#include <stdlib.h>
#include <stdbool.h>
#include <stdio.h>


/////////////////////////////////////////////////////////////////////////////////////snake///////////////////////////////////////////////////////////////////////////////////////

/**
 * \brief Largeur de l'écran de jeu du Snake
 */
#define SCREEN_WIDTH_SNAKE 850

/**
 * \brief Hauteur de l'écran de jeu du Snake
 */
#define SCREEN_HEIGHT_SNAKE 450

/**
 * \brief Nombre maximum de corps 
 */
#define NB_CORPS_SNAKE 200

/**
 * \brief Nombre maximum de pomme
 */
#define NB_POMME 6

/**
 * \brief Taille de la pomme
 */
#define SIZE_POMME 20

/**
 * \brief Taille de la limite a droite de la pomme
 */
#define SIZE_RIGHT_POMME 17

/**
 * \brief Taille de la limite a gauche de la pomme
 */
#define SIZE_LEFT_POMME 4

/**
 * \brief Taille du serpent a droite
 */
#define SIZE_RIGHT_SNAKE 20

/**
 * \brief Taille du serpent à gauche
 */
#define SIZE_LEFT_SNAKE 11

/**
 * \brief Taille du serpent en bas
 */
#define SIZE_BOTTOM_SNAKE 9

/**
 * \brief Taille du serpent en haut
 */
#define SIZE_TOP_SNAKE 0

/**
 * \brief Nombre maximum de Pierre
 */
#define NB_PIERRE 6

/**
 * \brief Taille de l'eau w
 */
#define WIDTH_EAU 128

/**
 * \brief Taille de l'eau
 */
#define HEIGHT_EAU 74


///////////////////////////////////////////////////////////////////////////////struct pomme///////////////////////////////////////////////////////////////////////////////////////

struct pomme_s{
	SDL_Surface* Pomme;
	int px,py;
	int exist;
};
typedef struct pomme_s pomme_t;

///////////////////////////////////////////////////////////////////////////////struct timer///////////////////////////////////////////////////////////////////////////////////////

struct timer_s{
	unsigned int TA; //temps ancien
	unsigned int TM; //temps maintenant
	int EA; //ecart d'apparition
	int ER; //ecart durant lequelle il restera
	int L; // lequel passage est prit en compte
};
typedef struct timer_s t_t;

/////////////////////////////////////////////////////////////////////////////////struct pierre///////////////////////////////////////////////////////////////////////////////////////

struct pierre_s{
	SDL_Surface* Pierre;
	int pa,pb;
};
typedef struct pierre_s pierre_t;


/////////////////////////////////////////////////////////////////////////////////struct eau///////////////////////////////////////////////////////////////////////////////////////

struct eau_s{
	SDL_Surface* Eau;
	int ex, ey;
};
typedef struct eau_s eau_t;

/////////////////////////////////////////////////////////////////////////////////struct corps/////////////////////////////////////////////////////////////////////////////////////

struct corps_s{
	SDL_Surface* Corps;
	double cx,cy;
};
typedef struct corps_s corps_t;


/////////////////////////////////////////////////////////////////////////////////struct snake/////////////////////////////////////////////////////////////////////////////////////

struct snake_s{
	SDL_Surface* background;
	SDL_Surface* fond;
	SDL_Surface* Serpent;
	pomme_t PR[200];
	corps_t corps;
	corps_t C[NB_CORPS_SNAKE];
	int gameover;
	double x,y;
	double vx, vy;
	int direct;
	int nb_corps;
	bool ouvert;
	int score;
	pomme_t PV[200];
	pomme_t PN[200];
	int nb_pomme;
	pierre_t P[NB_PIERRE];
	pomme_t PO;
	t_t T;
	eau_t E;
	pause_t pause;
	int laquel;
	resultat_t gagne;
	resultat_t perdu;

};
typedef struct snake_s snake_t;

