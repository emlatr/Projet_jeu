#ifndef PERDU_H
#define PERDU_H

#include "../sdl-light.h"

void refresh_graphics_perdu(SDL_Surface *screen, resultat_t *r);

void handle_events_perdu(SDL_Event *event_perdu, lab_t *lab, SDL_Surface *screen);

void boucle_perdu(lab_t *lab, SDL_Surface *screen);

#endif
