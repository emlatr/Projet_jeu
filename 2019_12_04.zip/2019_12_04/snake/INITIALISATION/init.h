/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */
#ifndef INIT_SNAKE_H
#define INIT_SNAKE_H


void init_data_snake(snake_t *snake);

void init_data_snake3_4(snake_t *snake);
 
void init_data_pomme(snake_t *snake);

void init_data_pomme1(snake_t *snake);

void init_data_pomme_or(SDL_Surface *screen, snake_t *snake);

int init_nb_pomme(snake_t *snake, int i);

void init_graphics_snake(SDL_Surface *screen, snake_t *snake);

void init_pierre(SDL_Surface *screen, snake_t *snake);

void init_eau(SDL_Surface *screen, snake_t *snake);

void init_timer(snake_t *snake);

#endif
