/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */



#include "colli.h"

int colli_pomme_pomme(pomme_t *p1, pomme_t *p2){
	if( (p1-> px + SIZE_RIGHT_POMME >= p2-> px + SIZE_LEFT_POMME ) && (p1-> px + SIZE_LEFT_POMME <= p2-> px + SIZE_RIGHT_POMME ) ){
		if( (p1-> py + SIZE_POMME >= p2-> py ) && (p1-> py <= p2-> py + SIZE_POMME ) ){
			return 1;
		}
	}
	return 0;
}

int colli_pomme_pierre(pomme_t *p1, pierre_t *p2, int i){
	if( (p1-> px + SIZE_RIGHT_POMME >= p2-> pa + SIZE_LEFT_POMME ) && (p1-> px + SIZE_LEFT_POMME <= p2-> pa + SIZE_RIGHT_POMME ) ){
		if( (p1-> py + SIZE_POMME >= p2-> pb + SIZE_LEFT_POMME ) && (p1-> py <= p2-> pb + SIZE_POMME ) ){
			if(i == 1){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
			if(i == 2 ){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
			if(i == 3 ){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
			if(i == 4){
				//printf("La pomme était en collision avec la pierre, c'est la raison pour laquelle elle à bougé\n");
				return 1;
			}
		}
	}
	return 0;
}

int colli_pierre_pierre(pierre_t *p1, pierre_t *p2){
	if( (p1-> pa + 32 >= p2-> pa ) && (p1-> pa <= p2-> pa + 32 ) ){
		if( (p1-> pb + 32 >= p2-> pb) && (p1-> pb <= p2-> pb + 32) ){
			return 1;
		}
	}
	return 0;
}
