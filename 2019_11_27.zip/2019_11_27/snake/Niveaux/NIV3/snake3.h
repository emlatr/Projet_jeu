/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.1
 * \date 12 septembre 2019
 */


#ifndef SNAKE_H
#define SNAKE_H

#include "../../../sdl-light.h"

void clean_data_snake3(snake_t *snake);

void verif(SDL_Surface *screen, snake_t *snake, lab_t *lab);

void refresh_graphics_snake3(SDL_Surface *screen, snake_t *snake, lab_t *lab);

void boucle_snake3(lab_t *lab, SDL_Surface *screen);

#endif
