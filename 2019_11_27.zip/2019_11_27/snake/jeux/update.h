/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.1
 * \date 12 septembre 2019
 */


#ifndef JEUX_H
#define JEUX_H

#include "../../sdl-light.h"

void update_serp(snake_t *snake);

void update_timer(snake_t *snake);

void update_data_snake(snake_t *snake);

void handle_events_snake(SDL_Event *event2, snake_t *snake, lab_t *lab, SDL_Surface *screen);

#endif
