/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */
#ifndef COLLI_LAB_H
#define COLLI_LAB_H

int collision_mur_Jean(lab_t *lab);

void collision_coffre(lab_t* lab, coffre_t* c, SDL_Surface* screen);

void collision_coffre_Jean(lab_t *lab, SDL_Surface* screen);

void collision_teleportation(lab_t *lab);

int colli_mur_monstre(lab_t *lab);

void colli_monstre_Jean(lab_t *lab);

#endif
