/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include "colli_lab.h"

int collision_mur_Jean(lab_t *lab){
	for(int i = 0; i< NB_MUR; i++){
		if(lab->deplace == 1){//le bas
			if(lab->M[i].x <= lab->x + 21  &&  lab->M[i].x >= lab->x + 12 ){
				for(int j = lab->M[i].y; j < (lab->M[i].y + lab->M[i].haut); j++){
					if(j <= (lab-> y + 20 + 8) && j >= lab->y + 20 + 8){
						return 1;
					}
				}
			}
		
			if(lab->M[i].y + lab->M[i].haut <= lab->y + 23 + 8  &&  lab->M[i].y >= lab->y + 8){
				for(int k = lab->M[i].x; k < (lab->M[i].x + lab->M[i].larg); k++){
					if(k <= (lab-> x + 21) && k >= lab->x + 12){
						return 1;
					}
				}
			}
		}
		
		if(lab->deplace == 0){
			if(lab->M[i].x <= lab->x + 21  &&  lab->M[i].x >= lab->x + 12 ){
				for(int j = lab->M[i].y; j < (lab->M[i].y + lab->M[i].haut); j++){
					if(j <= (lab-> y + 9 - 8) && j >= lab->y - 8){
						return 1;
					}
				}
			}
		
			if(lab->M[i].y <= lab->y + 9 - 8  &&  lab->M[i].y >= lab->y - 8){
				for(int k = lab->M[i].x; k < (lab->M[i].x + lab->M[i].larg); k++){
					if(k <= (lab-> x + 21) && k >= lab->x + 12){
						return 1;
					}
				}
			}
		}

		if(lab->deplace == 2){
			if(lab->M[i].x <= lab->x + 21 +8 &&  lab->M[i].x >= lab->x + 12 +8){
				for(int j = lab->M[i].y; j < (lab->M[i].y + lab->M[i].haut); j++){
					if(j <= (lab-> y + 9) && j >= lab->y){
						return 1;
					}
				}
			}
		
			if(lab->M[i].y <= lab->y + 9   &&  lab->M[i].y >= lab->y){
				for(int k = lab->M[i].x; k < (lab->M[i].x + lab->M[i].larg); k++){
					if(k <= (lab-> x + 21 + 8) && k >= lab->x + 12 + 8){
						return 1;
					}
				}
			}
		}

		if(lab->deplace == 3){
			if(lab->M[i].x <= lab->x + 21  - 8 &&  lab->M[i].x >= lab->x + 12  - 8){
				for(int j = lab->M[i].y; j < (lab->M[i].y + lab->M[i].haut); j++){
					if(j <= (lab-> y + 9) && j >= lab->y){
						return 1;
					}
				}
			}
		
			if(lab->M[i].y <= lab->y + 9 &&  lab->M[i].y >= lab->y){
				for(int k = lab->M[i].x; k < (lab->M[i].x + lab->M[i].larg); k++){
					if(k <= (lab-> x + 21 - 8) && k >= lab->x + 12 - 8){
						return 1;
					}
				}
			}
		}
	}
	return 0;
}

void collision_coffre(lab_t* lab, coffre_t* c, SDL_Surface* screen){
	if( (lab->x + 21 >= c->cx ) && (lab->x + 12 <= c->cx + SIZE_RIGHT_COFFRE ) ){
		if( (lab->y + 26 >= c->cy ) && (lab->y <= c->cy + 26 ) ){
			printf("coucou\n");
			lab->compt++;
			if(lab->compt == 1)
				boucle_snake3(lab, screen);
			else if(lab->compt == 2)
				boucle_snake2(lab, screen);
			else if(lab->compt == 3)
				boucle_snake3(lab, screen);
			else if(lab->compt == 4)
				boucle_snake4(lab, screen);
			else if(lab->compt == 5)
				boucle_snake5(lab, screen);
			printf("coucou\n");
			c-> exist = 0;
			c->cy = -100;
			c->cx = -100;
			return;
		} 

	}
	return;
}

void collision_coffre_Jean(lab_t *lab, SDL_Surface* screen){
	for(int i = 0; i<NB_COFFRE; i++){
		collision_coffre(lab, &lab->Co[i], screen);
	}
}

void collision_teleportation(lab_t *lab){
	if(lab->deplace == 0){
		if(lab->M[33].y <= lab->y + 23 - 8 &&  lab->M[33].y >= lab->y - 8){
			for(int k = lab->M[33].x + 4; k < (lab->M[33].x + lab->M[33].larg - 4); k++){
				if(k <= (lab-> x + 21) && k >= lab->x + 12){
					lab-> x = lab->M[44].x + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[44].y + lab->M[44].haut + 10;
					return ;
				}
			}
		}
		if(lab->M[44].y <= lab->y + 23 - 8 &&  lab->M[44].y >= lab->y - 8){
			for(int k = lab->M[44].x + 4; k < (lab->M[44].x + lab->M[44].larg - 4); k++){
				if(k <= (lab-> x + 21) && k >= lab->x + 12){
					lab-> x = lab->M[33].x + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[33].y + lab->M[33].haut + 10;
					return ;
				}
			}
		}
		if(lab->M[40].y <= lab->y + 23 - 8 &&  lab->M[40].y >= lab->y - 8){
			for(int k = lab->M[40].x + 4; k < (lab->M[40].x + lab->M[40].larg - 8); k++){
				if(k <= (lab-> x + 21 - 10) && k >= lab->x + 12 - 10){
					lab-> x = lab->M[51].x + 44 + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[51].y + lab->M[51].haut + 10;
					return ;
				}
			}
		}
		if(lab->M[51].y <= lab->y + 23 - 8 &&  lab->M[51].y >= lab->y - 8){
			for(int k = lab->M[51].x + 4; k < (lab->M[51].x + lab->M[51].larg - 8); k++){
				if(k <= (lab-> x + 21 - 10) && k >= lab->x + 12 - 10){
					lab-> x = lab->M[40].x + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[40].y + lab->M[40].haut + 10;
					return ;
				}
			}
		}
		if(lab->M[42].y <= lab->y + 23 - 8 &&  lab->M[42].y >= lab->y - 8){
			for(int k = lab->M[42].x + 4; k < (lab->M[42].x + lab->M[42].larg - 8); k++){
				if(k <= (lab-> x + 21 - 10) && k >= lab->x + 12 - 10){
					lab-> x = lab->M[45].x + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[45].y + lab->M[45].haut + 10;
					return ;
				}
			}
		}
		if(lab->M[45].y <= lab->y + 23 - 8 &&  lab->M[45].y >= lab->y - 8){
			for(int k = lab->M[45].x + 4; k < (lab->M[45].x + lab->M[45].larg - 8); k++){
				if(k <= (lab-> x + 21 - 10) && k >= lab->x + 12 - 10){
					lab-> x = lab->M[42].x + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[42].y + lab->M[42].haut + 10;
					return ;
				}
			}
		}
		if(lab->M[47].y <= lab->y + 23 - 8 &&  lab->M[47].y >= lab->y - 8){
			for(int k = lab->M[47].x + 4; k < (lab->M[47].x + lab->M[47].larg -4); k++){
				if(k <= (lab-> x + 21 - 10) && k >= lab->x + 12 - 10){
					lab-> x = lab->M[41].x + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[41].y - 21 - 10;
					return ;
				}
			}
		}
		
	}
	if(lab->deplace == 1){
		if(lab->M[41].y <= lab->y + 23 + 8 &&  lab->M[41].y >= lab->y + 8){
			for(int k = lab->M[41].x + 4; k < (lab->M[41].x + lab->M[41].larg - 8); k++){
				if(k <= (lab-> x + 21 - 10) && k >= lab->x + 12 - 10){
					lab-> x = lab->M[47].x + 16;//16 : taille pour centrer un minimum le Jean
					lab-> y = lab->M[47].y + lab->M[47].haut + 10;
					return ;
				}
			}
		}
	}
}


int colli_mur_monstre(lab_t * lab/*, monstre_t *monstre*/){
	if( (lab->monstre.mx + 100 >= lab->M[44].x ) && (lab->monstre.mx + 30 <= lab->M[44].x + 48) ){
		if( (lab->monstre.my + 55 >= lab->M[44].y  ) && (lab->monstre.my + 28 <= lab->M[44].y + 4) ){
			lab->monstre.direct = 1;
			return 1;
		}
	}
	
	if( (lab->monstre.mx + 100 >= lab->M[41].x ) && (lab->monstre.mx + 30 <= lab->M[41].x + 48) ){
		if( (lab->monstre.my + 55 >= lab->M[41].y  ) && (lab->monstre.my + 28 <= lab->M[41].y + 4) ){
			lab->monstre.direct = 0;
			return 1;
		}
	}
	return 0;
}

void colli_monstre_Jean(lab_t *lab){
	if( (lab->x  + 21  >= lab->monstre.mx + 10 ) && ( lab->x + 12 <=lab->monstre.mx + 48) ){
		if( (lab->y + 26 >= lab->monstre.my + 29 ) && ( lab->y <=lab->monstre.my + 56 ) ){
			printf("Aie aie Aie !!!\n");
			lab-> x = 0.;
			lab-> y = 0.;
		}
	}
}

