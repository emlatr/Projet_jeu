/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

//#include "../sdl-light.h"
//#include "../general.h"
//#include "COLLISION/colli.h"
#include <time.h>


void pomme_new(pomme_t *pomme){
	srand( (unsigned) time(NULL));
	pomme->px = rand() % 830 + 0;
	pomme->py = rand() % 430 + 0;
	pomme->exist = 1;
}

int collision_pomme(snake_t *snake){
	int x = -1;
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PR[i], 1)){
				pomme_new(&snake->PR[i]);
				snake->laquel = 1;
				return x = i;
			}
		}
		if(snake-> PV[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PV[i], 2)){
				pomme_new(&snake->PV[i]);
				snake->laquel = 2;
				return x = i;
			}
		}
		if(snake-> PN[i].exist == 1){
			if(collision_pomme_serp(snake, &snake-> PN[i], 3)){
				pomme_new(&snake->PN[i]);
				snake->laquel = 3;
				return x = i;
			}
		}
	}
	if(snake->T.L == 2){
		if(collision_pomme_serp(snake, &snake-> PO, 4)){
			snake->laquel = 4;
			return x = 12;
		}
	}
	return -1;
}

void pomme_pomme(snake_t *snake){
	for(int i = 0; i < snake-> nb_pomme; i++){
		for(int j = 0; j < snake-> nb_pomme; i++){
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PR[j+1])){
				pomme_new(&snake-> PR[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PV[i], &snake-> PV[j+1])){
				pomme_new(&snake-> PV[j]);
				return;		
			}
			if(colli_pomme_pomme(&snake-> PN[i], &snake-> PN[j+1])){
				pomme_new(&snake-> PN[j]);
				return;		
			}
			
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PV[j])){
				if(snake->laquel == 1){
					pomme_new(&snake-> PR[i]);
					return;
				}
				pomme_new(&snake-> PV[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PN[j])){
				if(snake->laquel == 1){
					pomme_new(&snake-> PR[i]);
					return;
				}
				pomme_new(&snake-> PN[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PR[i], &snake-> PO)){
				if(snake->laquel == 1){
					pomme_new(&snake-> PR[i]);
					return;
				}
				pomme_new(&snake-> PO);
				return;	
			}

			
			if(colli_pomme_pomme(&snake-> PV[i], &snake-> PN[j])){
				if(snake->laquel == 1){
					pomme_new(&snake-> PV[i]);
					return;
				}
				pomme_new(&snake-> PN[j]);
				return;	
			}
			if(colli_pomme_pomme(&snake-> PV[i], &snake-> PO)){
				if(snake->laquel == 1){
					pomme_new(&snake-> PV[i]);
					return;
				}
				pomme_new(&snake-> PO);
				return;	
			}

			if(colli_pomme_pomme(&snake-> PN[i], &snake-> PO)){
				if(snake->laquel == 1){
					pomme_new(&snake-> PN[i]);
					return;
				}
				pomme_new(&snake-> PO);
				return;	
			}
		}
	}
	return;
}



int collision_pomme_pierre(snake_t *snake){
	int x = -1;
	for(int i = 0; i < snake->nb_pomme; i++){
		for(int j = 0; j < NB_PIERRE; j++){
			if(snake-> PR[i].exist == 1){
				if(colli_pomme_pierre(&snake-> PR[i], &snake-> P[j], 1)){
					pomme_new(&snake->PR[i]);
					snake->laquel = 1;
					return x = i;
				}
			}
			if(snake-> PV[i].exist == 1){
				if(colli_pomme_pierre(&snake-> PV[i], &snake-> P[j], 2)){
					pomme_new(&snake->PV[i]);
					snake->laquel = 2;
					return x = i;
				}
			}
			if(snake-> PN[i].exist == 1){
				if(colli_pomme_pierre(&snake-> PN[i], &snake-> P[j], 3)){
					pomme_new(&snake->PN[i]);
					snake->laquel = 3;
					return x = i;
				}
			}
			if(snake->T.L == 2){
				if(colli_pomme_pierre(&snake-> PO, &snake-> P[j], 4)){
					snake->laquel = 4;
					return x = 12;
				}
			}
		}
	}
	return -1;
}

int collision_pierre_pierre(snake_t *snake){
	for(int i = 0; i < NB_PIERRE; i++){
		for(int j = 0; j < NB_PIERRE; j++){
			if(colli_pierre_pierre(&snake-> P[i], &snake-> P[j]) || i!=j){
				srand( (unsigned) time(NULL));
				snake->P[i].pa = rand() % 830 + 0;
				snake->P[i].pb = rand() % 430 + 0;
				return 1;
			}
		}
	}
	return 0;
}


