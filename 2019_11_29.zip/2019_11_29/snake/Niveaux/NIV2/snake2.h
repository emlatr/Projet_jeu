/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.1
 * \date 12 septembre 2019
 */


#ifndef SNAKE_H
#define SNAKE_H

#include "../../../sdl-light.h"

void clean_data_snake2(snake_t *snake);

void refresh_graphics_snake2(SDL_Surface *screen, snake_t *snake, lab_t *lab);

void boucle_snake2(lab_t *lab, SDL_Surface *screen);

#endif
