#ifndef INIT_PAUSE_H
#define INIT_PAUSE_H

#include "../../sdl-light.h"

void init_data_pause(pause_t *p);

#endif
