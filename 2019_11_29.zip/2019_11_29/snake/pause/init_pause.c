#include "../../general.h"

void init_data_pause(pause_t *p){

	p-> Pause = load_image("ressources/Pause.bmp");

	p-> ouvert = true;
	
}
