#include "../sdl-light.h"
#include <stdbool.h>

/**
 * \brief Nombre maximum de pomme
 */
#define LARGEUR_BOUTON_MENU 300

/**
 * \brief Taille de la pomme
 */
#define HAUTEUR_BOUTON_MENU 100

/**
 * \brief Taille de la limite a droite de la pomme
 */
#define ECART_BORDURE_MENU 20

/**
 *
 */ 
#define NB_BOUTON_MAX_MENU 2

///////////////////////////////////////////////////////////////////////////////struct souris/////////////////////////////////////////////////////////////////////////////////////

struct souris_s{
	int x,y;
	int cx, cy;
};
typedef struct souris_s souris_t;

///////////////////////////////////////////////////////////////////////////////struct bouton/////////////////////////////////////////////////////////////////////////////////////

struct bouton_menu_s{
	SDL_Surface* Bouton;
	SDL_Surface* Bouton_des;
	SDL_Surface* Bouton_pas_des;
	int x, y;
	int larg;
	int haut;
	int lequel; //1 = bouton_1, 2 = bouton_2
};
typedef struct bouton_menu_s bouton_menu_t;

///////////////////////////////////////////////////////////////////////////////struct menu///////////////////////////////////////////////////////////////////////////////////////

struct menu_s{
	SDL_Surface* Menu;
	bool ouvert;
	int nbBouton;
	bouton_menu_t taBouton[NB_BOUTON_MAX_MENU];
	souris_t souris;
};
typedef struct menu_s menu_t;
