/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.1
 * \date 12 septembre 2019
 */

#include "general.h"
#include "Menu/init_menu.h"
#include "Menu/menu.h"
#include "Regle/init_regle.h"
#include "Regle/regle.h"
#include "Lab/collision/colli_lab.c"
#include "Lab/initialisation/init_lab.c"
#include <SDL2/SDL_ttf.h>

/**
 * \brief La fonction met à jour les données du monstre
 * \param lab les données du monde
 */
void update_monstre(lab_t *lab){
	if(lab->monstre.direct == 0)
		lab->monstre.my += lab->monstre.vmy;
	else if(lab->monstre.direct == 1)
		lab->monstre.my -= lab->monstre.vmy;
}


/**
 * \brief La fonction nettoie les données du monde
 * \param lab les données du monde
 */
void clean_data(lab_t *lab){
	SDL_FreeSurface(lab->background);
	SDL_FreeSurface(lab->Lampe);
	SDL_FreeSurface(lab->Jean);
	SDL_FreeSurface(lab->Jean2);
	SDL_FreeSurface(lab->Jean3);
	SDL_FreeSurface(lab->Jean4);
	SDL_FreeSurface(lab->monstre.Monstre);
}



/**
 * \brief La fonction indique si le jeu est fini en fonction des données du monde
 * \param lab les données du monde
 * \return 1 si le jeu est fini, 0 sinon
 */
int is_game_over(lab_t *lab){
	return lab->gameover;
}

/**
 * \brief La fonction applique la surface de l'image de fond à quatre positions différentes sur l'écran de jeu, de sorte de complètement couvrir ce dernier
 * \param screen l'écran de jeu
 * \param bg la surface de l'image de fond
 */
void apply_background(SDL_Surface *bg, SDL_Surface *screen){
	apply_surface(bg,screen,0,0);
}

/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du monde
 * \param screen la surface de l'écran de jeu
 * \param lab les données du monde
 */
void refresh_graphics(SDL_Surface *screen, lab_t *lab){
	apply_background(lab->background,screen);
	apply_surface(lab->Jean, screen, lab->x , lab->y);
	for(int i = 0; i< NB_COFFRE; i++){
		if(lab-> Co[i].exist == 1){
			apply_surface(lab->Co[i].Coffre, screen, lab->Co[i].cx, lab->Co[i].cy);
		}
	}
	apply_surface(lab->monstre.Monstre, screen, lab->monstre.mx, lab->monstre.my);
	apply_surface(lab->Lampe, screen, lab->x-1480, lab->y - 1500);
	apply_surface(lab->intero, screen, lab->Co[0].cx-5, lab->Co[0].cy-8);

	colli_monstre_Jean(lab);
	colli_mur_monstre(lab);
	if(lab->y < 0){
		lab->y = 0;
	}
	//colli_monstre_Jean(lab);


	refresh_surface(screen);
}

/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event paramètre qui contient les événements
 * \param lab les données du monde
 */
void handle_events(SDL_Event *event,lab_t *lab, SDL_Surface* screen){
	Uint8 *keystates;
	while( SDL_PollEvent( event ) ) {
	//Si l'utilisateur a cliqué sur le X de la fenêtre
		if( event->type == SDL_QUIT ) {
		  	//On quitte le programme
			lab->gameover = 1;
		}
		/* gestion des evenements clavier */
		keystates = SDL_GetKeyState( NULL );
		//printf("%i",collision_coffre_Jean(lab));
		if(keystates[SDLK_e]){
			collision_coffre_Jean(lab, screen);
		}
		/* Si l'utilisateur appuie sur les flèches, le personnage se déplace */
		if(keystates[SDLK_UP])
		{
			lab->deplace = 0;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean4;
				lab->Lampe = lab->Lampe_haut;
				lab->y-=10;
			}

		}
		else if(keystates[SDLK_DOWN])
		{
			lab->deplace = 1;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean1;
				lab->Lampe = lab->Lampe_bas;
				lab->y+=10;
			}
		}
		else if(keystates[SDLK_RIGHT])
		{
			lab->deplace = 2;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean2;
				lab->Lampe = lab->Lampe_droite;
				lab->x+=10;
			}
		}
		else if(keystates[SDLK_LEFT])
		{
			lab->deplace = 3;
			if(collision_mur_Jean(lab) != 1){
				lab->Jean = lab->Jean3;
				lab->Lampe = lab->Lampe_gauche;
				lab->x-=10;
			}
		}
	}
}

/**
 *  \brief programme principal qui implémente la boucle du jeu
 */
int main( int argc, char* args[] )
{
	//SDL_Event event;
	//lab_t lab;
	//SDL_Surface *screen;


    SDL_Surface *ecran = NULL, *texte = NULL, *fond = NULL;
    SDL_Rect position;
    SDL_Event event;
    TTF_Font *police = NULL;
    SDL_Color couleurNoire = {0, 0, 0};
    int continuer = 1;

    SDL_Init(SDL_INIT_VIDEO);
    TTF_Init();

    ecran = SDL_SetVideoMode(640, 480, 32, SDL_HWSURFACE | SDL_DOUBLEBUF);
    SDL_WM_SetCaption("Gestion du texte avec SDL_ttf", NULL);

    fond = IMG_Load("moraira.jpg");

    /* Chargement de la police */
    police = TTF_OpenFont("angelina.ttf", 65);
    /* Écriture du texte dans la SDL_Surface texte en mode Blended (optimal) */
    texte = TTF_RenderText_Blended(police, "Salut les Zér0s !", couleurNoire);

    while (continuer)
    {
        SDL_WaitEvent(&event);
        switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
        }

        SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 255, 255, 255));

        position.x = 0;
        position.y = 0;
        SDL_BlitSurface(fond, NULL, ecran, &position); /* Blit du fond */

        position.x = 60;
        position.y = 370;
        SDL_BlitSurface(texte, NULL, ecran, &position); /* Blit du texte */
        SDL_Flip(ecran);
    }

    TTF_CloseFont(police);
    TTF_Quit();

    SDL_FreeSurface(texte);
    SDL_Quit();

    return EXIT_SUCCESS;




	/*int TTF_Init();
	TTF_Font *font = TTF_OpenFont("/arial.ttf",28);*/
	/*SDL_Color color = {0,0,0,0};
	char msg[] = "TP sur Makefile et SDL";
	SDL_GLattr* texte = charger_texte(msg,screen,font,color);
	SDL_Rect text_pos; // Position du texte
	text_pos.x = 10;
	text_pos.y = 100;
	text_pos.w = 100; // Largeur du texte en pixels (à récupérer)
	text_pos.h = 100; // Hauteur du texte en pixels (à récupérer)
		// Boucle principalewhile(!terminer)
	
	SDL_RenderCopy(screen,texte,NULL,&text_pos);*/
	

	
	/*screen = init_sdl(SCREEN_WIDTH, SCREEN_HEIGHT);
	boucle_menu(&lab, screen);
	SDL_WM_SetCaption("Fenêtre de jeu de labyrinthe !", NULL);
	init_data(&lab);
	init_mur(&lab);
	init_graphics(screen,&lab);
	SDL_EnableKeyRepeat(100, 100); //active la répétition des touches
	while(!is_game_over(&lab)){
		SDL_WM_SetCaption("Fenêtre de jeu de labyrinthe !", NULL);
		collision_teleportation(&lab);
		update_monstre(&lab);
		handle_events(&event,&lab, screen);
		refresh_graphics(screen,&lab);
		SDL_Delay(10);
			
	}*/
	//clean_data(&lab);
	/*TTF_CloseFont( font );
	TTF_Quit();*/
	//quit_sdl();
	return 0;
}
