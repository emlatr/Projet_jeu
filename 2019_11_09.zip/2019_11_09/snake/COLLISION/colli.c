/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include <time.h>
#include "colli.h"


int collision_snake (snake_t *snake){
	if(snake-> x + 20 > SCREEN_WIDTH_SNAKE){
		return 1;
	}
	if(snake-> x < 0.){
		return 2;
	}
	if(snake-> y + 23 > SCREEN_HEIGHT_SNAKE){
		return 3;
	}
	if(snake-> y < 0.){
		return 4;
	}
	return 0;
}
 
void replacement_serpent(snake_t *snake){
	if(collision_snake(snake) == 1){
		snake-> x = 0.1;
		return;
	}
	if(collision_snake(snake) == 2){
		snake-> x = SCREEN_WIDTH_SNAKE - 20;
		return;
	}
	if(collision_snake(snake) == 3){
		snake-> y = 0.1;
		return;
	}
	if(collision_snake(snake) == 4){
		snake-> y = SCREEN_HEIGHT_SNAKE - 23;
		return;
	}
	return;
}


int collision_pomme_serp(snake_t *snake, pomme_t *p, int i){
	if( (snake-> x + SIZE_RIGHT_SNAKE >= p-> px + SIZE_LEFT_POMME ) && (snake-> x + SIZE_LEFT_SNAKE <= p-> px + SIZE_RIGHT_POMME ) ){
		if( (snake-> y + SIZE_BOTTOM_SNAKE >= p-> py + SIZE_LEFT_POMME ) && (snake-> y <= p-> py + SIZE_POMME ) ){
			if(i == 1){
				snake-> nb_corps += 2;
				snake-> score += 1;
				printf("Votre score est de : %i\n", snake-> score);
				p-> exist = 0;
				return 1;
			}
			if(i == 2 ){
				snake-> nb_corps += 1;
				snake-> score += 1;
				printf("Votre score est de : %i\n", snake-> score);
				p-> exist = 0;
				return 1;
			}
			if(i == 3 ){
				snake-> score -= 5;
				if(snake-> score < 0){
					snake->score = 0;
				}
				printf("Votre score est de : %i\n", snake-> score);
				p-> exist = 0;
				return 1;
			}
			if(i == 4){
				snake-> score += 10;
				printf("Votre score est de : %i\n", snake-> score);
				p->px = -100;
				p->py = -100;
				snake->T.L = 1;
				return 1;
			}
		}
	}
	return 0;
}



int collision_tete_corps(snake_t *snake, corps_t *corps){
	if( (snake-> x + SIZE_RIGHT_SNAKE + SIZE_RIGHT_SNAKE == corps-> cx) && (snake-> y == corps-> cy ) )
		return 1;
	if( (snake-> x + SIZE_RIGHT_SNAKE == corps-> cx + SIZE_RIGHT_SNAKE ) && (snake-> y == corps-> cy ) )
		return 1;
	if( (snake-> x == corps-> cx ) && (snake-> y + SIZE_BOTTOM_SNAKE == corps-> cy + SIZE_BOTTOM_SNAKE ) )
		return 1;
	return 0;
}


int collision_corps(snake_t *snake){
	for(int i = 0; i < snake->nb_corps; i++){
		if ( collision_tete_corps(snake, &snake-> C[i]) == 1 ){
			printf("Vous avez touché le corps du serpent ! Vous venez donc de perdre ! \n");
			snake->vx = 0;
			snake->vy = 0;
			return 1;
		}
	}
	return 0;
}

int collision_pierre_serp(snake_t *snake, pierre_t *p){
	if( (snake-> x + SIZE_RIGHT_SNAKE + 2 >= p-> pa) && (snake-> x + SIZE_LEFT_SNAKE - 1 <= p-> pa + 32 ) ){
		if( (snake-> y + SIZE_BOTTOM_SNAKE + 4 >= p-> pb ) && (snake-> y <= p-> pb + 32 ) ){
			printf("Vous venez de toucher une pierre et vous êtes donc tombez dans les pommes ! Veuillez recommencer !\n ");
			return 1;
		}
	}
	return 0;
}

