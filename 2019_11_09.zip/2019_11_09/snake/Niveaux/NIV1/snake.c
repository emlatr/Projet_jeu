/**
 * \file main.c
 * \brief Programme principal du niveau 0
 * \author BONTE Emeline, DEBART Arthur
 * \version 0.2
 * \date 21 octobre 2019
 */

#include "../../../sdl-light.h"
#include "../../../general.h"
#include <time.h>
#include "snake.h"
#include "../../INITIALISATION/init.c"
#include "../../COLLISION/colli.c"
#include "../../snake_jeu.c"



/**
 * \brief La fonction met à jour les données du serpent
 * \param world les données du monde
 */
void update_serp(snake_t *snake){
	for(int i = snake-> nb_corps-1; i>0; i--){
		snake-> C[i].cx = snake-> C[i-1].cx;
		snake-> C[i].cy = snake-> C[i-1].cy;
	}
	snake-> C[0].cx = snake-> x;
	snake-> C[0].cy = snake-> y;
	if(snake-> direct == 0 ){
		snake-> x += snake-> vx;
	}
	else if(snake-> direct == 1){
		snake-> y += snake-> vy;
	}
	else if(snake-> direct == 2){
		snake->x -= snake->vx;
	}
	else if(snake-> direct == 3){
		snake-> y -= snake-> vy;
	}
}

/**
 * \brief La fonction nettoie les données du monde
 * \param world les données du monde
 */
void clean_data_snake(snake_t *snake){
	SDL_FreeSurface(snake-> background);
	SDL_FreeSurface(snake-> fond);
	SDL_FreeSurface(snake-> PR[NB_POMME].Pomme);
	SDL_FreeSurface(snake-> Serpent);
}

/**
 * \brief La fonction met à jour les données en tenant compte de la physique du monde
 * \param les données du monde
 */
void update_data_snake(snake_t *snake){
	update_serp(snake);
}



/**
 * \brief La fonction rafrachit l'écran en fonction de l'état des données du monde
 * \param screen la surface de l'écran de jeu
 * \param world les données du monde
 */
void refresh_graphics_snake(SDL_Surface *screen, snake_t *snake, lab_t *lab){
	apply_surface(snake-> fond, screen, 0, 0);
	apply_surface(snake-> background, screen, 0, 0);
	for(int i = 0; i < snake->nb_pomme; i++){
		if(snake-> PR[i].exist == 1){
			apply_surface(snake-> PR[i].Pomme, screen, snake-> PR[i].px, snake-> PR[i].py);
		}
		/*if(snake-> PV[i].exist == 1){
			apply_surface(snake-> PV[i].Pomme, screen, snake-> PV[i].px, snake-> PV[i].py);
		}*/
	}
	apply_surface(snake-> Serpent, screen, snake-> x , snake-> y);
	for(int i = 0; i < snake-> nb_corps; i++){
		apply_surface(snake-> C[i].Corps, screen, snake-> C[i].cx, snake-> C[i].cy);
	}
	if(collision_corps(snake) == 1){
		boucle_snake(lab, screen);
	}
	collision_pomme(snake);
	if(snake-> score >= 20){
		snake-> ouvert = false;
		snake-> score = 0;
	}
	refresh_surface(screen);
}

/**
 * \brief La fonction gère les évènements ayant eu lieu et qui n'ont pas encore été traités
 * \param event paramètre qui contient les événements
 * \param world les données du monde
 */
void handle_events_snake(SDL_Event *event2, snake_t *snake, lab_t *lab, SDL_Surface *screen){
	Uint8 *keystates;
	while(SDL_PollEvent(event2)){
		//Si l'utilisateur a cliqué sur le X de la fenêtre
		if(event2-> type == SDL_QUIT){
		  //On quitte le programme
			lab-> gameover = 1;
			snake-> ouvert = false;
		}
		/* gestion des evenements clavier */
		keystates = SDL_GetKeyState(NULL);
		/* Si l'utilisateur appuie sur les flèches, le personnage se déplace */
		if(keystates[SDLK_UP])
		{
			snake-> direct = 3;
		}
		else if(keystates[SDLK_DOWN])
		{
			snake-> direct = 1;
		}
		else if(keystates[SDLK_RIGHT])
		{
			snake-> direct = 0;
		}
		else if(keystates[SDLK_LEFT])
		{
			snake-> direct = 2;
		}
		else if(keystates[SDLK_p])
		{
			//boucle_pause(world, screen);
		}
	}
}

/**
 *  \brief programme principal qui implémente la boucle du jeu
 */
void boucle_snake(lab_t *lab, SDL_Surface *screen){
	SDL_Event event2;
	SDL_WM_SetCaption("Fenêtre de jeu de snake !", NULL);
	init_data_snake(&lab-> snake);
	lab->snake.nb_pomme = init_nb_pomme(&lab->snake, 1);
	printf("%i\n", lab->snake.nb_pomme);
	init_data_pomme1(&lab-> snake);
	init_graphics_snake(screen, &lab-> snake);
	while(lab-> snake.ouvert == true){
		handle_events_snake(&event2, &lab-> snake, lab, screen);
		update_data_snake(&lab-> snake);
		refresh_graphics_snake(screen,&lab-> snake, lab);
		SDL_Delay(100);
		if(collision_snake(&lab-> snake)){
			replacement_serpent(&lab-> snake);
		}
	}
	clean_data_snake(&lab-> snake);
	return;
}
