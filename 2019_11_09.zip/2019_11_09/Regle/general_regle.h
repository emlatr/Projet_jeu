#include "../sdl-light.h"
#include <stdbool.h>

/**
 * \brief Nombre maximum de pomme
 */
#define LARGEUR_BOUTON_REGLE 300

/**
 * \brief Taille de la pomme
 */
#define HAUTEUR_BOUTON_REGLE 100

/**
 * \brief Taille de la pomme
 */
#define X_BOUTON_REGLE 650

/**
 * \brief Taille de la pomme
 */
#define Y_BOUTON_REGLE 400

///////////////////////////////////////////////////////////////////////////////struct souris/////////////////////////////////////////////////////////////////////////////////////

struct souris_regle_s{
	int x,y;
	int cx, cy;
};
typedef struct souris_regle_s souris_regle_t;

///////////////////////////////////////////////////////////////////////////////struct bouton/////////////////////////////////////////////////////////////////////////////////////

struct bouton_regle_s{
	SDL_Surface* Bouton;
	SDL_Surface* Bouton_des;
	SDL_Surface* Bouton_pas_des;
	int x, y;
	int larg;
	int haut;
};
typedef struct bouton_regle_s bouton_regle_t;

///////////////////////////////////////////////////////////////////////////////struct menu///////////////////////////////////////////////////////////////////////////////////////

struct regle_s{
	SDL_Surface* Regle;
	bool ouvert;
	bouton_regle_t bouton;
	souris_regle_t souris;
};
typedef struct regle_s regle_t;
