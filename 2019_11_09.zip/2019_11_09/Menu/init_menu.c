#include "../general.h"

void init_data_souris_menu(souris_t *s){
	s-> x = -100;
	s-> y = -100;	
	s-> cx = -100;	
	s-> cy = -100;		 
}

void init_data_bouton_menu_1(bouton_menu_t *b, int x){
	b-> Bouton_des = load_image("ressources/menu_b_2.bmp");
	b-> Bouton_pas_des = load_image("ressources/menu_b_1.bmp");

	b-> Bouton = b-> Bouton_pas_des;

	b-> larg = LARGEUR_BOUTON_MENU;	
	b-> haut = HAUTEUR_BOUTON_MENU;

	b-> y = SCREEN_HEIGHT/2 - b->haut/2;
	b-> x = x; 

	b-> lequel = 1;
}

void init_data_bouton_menu_2(bouton_menu_t *b, int x){
	b-> Bouton_des = load_image("ressources/menu_b_1.bmp");
	b-> Bouton_pas_des = load_image("ressources/menu_b_2.bmp");

	b-> Bouton = b-> Bouton_pas_des;

 	b-> larg = LARGEUR_BOUTON_MENU;	
	b-> haut = HAUTEUR_BOUTON_MENU;

	b-> y = SCREEN_HEIGHT/2 - b->haut/2;
	b-> x = x;

	b-> lequel = 2;
}

void init_data_bouton_menu_i(bouton_menu_t *b, int x, int i){
	if(i == 0){
		init_data_bouton_menu_1(b, x);
		return;
	}
	init_data_bouton_menu_2(b, x);
	return;
}

void init_data_menu(menu_t *m){
	int x = ECART_BORDURE_MENU;	

	m-> Menu = load_image("ressources/fond_arthur.bmp");

	m-> ouvert = true;

	m-> nbBouton = 2;

	for(int i = 0; i < m-> nbBouton; i++){
		init_data_bouton_menu_i(&m-> taBouton[i], x, i);
		x = SCREEN_WIDTH - ECART_BORDURE_MENU - LARGEUR_BOUTON_MENU;
	}
	
	init_data_souris_menu(&m-> souris);	
}
